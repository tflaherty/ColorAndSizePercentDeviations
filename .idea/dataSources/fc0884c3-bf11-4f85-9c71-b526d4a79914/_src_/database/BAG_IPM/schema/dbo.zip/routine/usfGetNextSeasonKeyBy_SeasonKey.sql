-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION usfGetNextSeasonKeyBy_SeasonKey 
(
	@SeasonKey int
)
	returns int
AS
BEGIN
	DECLARE @NextSeasonKey int

	SELECT    Top 1 @NextSeasonKey = s2.Season_key 
	FROM         Season AS s1 INNER JOIN
						  Season AS s2 ON s1.StartDate < s2.StartDate 
	WHERE     (s1.Season_key = @SeasonKey) 
	ORDER BY s2.StartDate ASC

	-- Return the result of the function
	RETURN @NextSeasonKey

END
GO
