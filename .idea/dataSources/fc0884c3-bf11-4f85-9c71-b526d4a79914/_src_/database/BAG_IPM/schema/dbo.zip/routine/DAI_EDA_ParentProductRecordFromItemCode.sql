-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[DAI_EDA_ParentProductRecordFromItemCode]
(	
	@ItemCode int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT
			*
		from MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr
		where pr.INVENTORY = 'PP'
		and SUBSTRING(pr.ID, PATINDEX('%[^0]%', pr.ID), LEN(pr.ID)) = CAST(@ItemCode as varchar(255))
)
GO
