CREATE VIEW dbo.ShoeColorsThatCantBeMapped
AS
SELECT ShoeColor_key, ShoeColor_code, ShoeDescription, ShoeIsShoeColor,
                   (SELECT COUNT(*) AS Expr1
                    FROM   dbo.SKU AS s
                    WHERE (Color_fkey = a.ShoeColor_key)) AS ShoeSKUs, NonShoeColor_key, NonShoeColor_code, NonShoeDescription, NonShoeIsShoeColor,
                   (SELECT COUNT(*) AS Expr1
                    FROM   dbo.SKU AS s
                    WHERE (Color_fkey = a.NonShoeColor_key)) AS NonShoeSKUs
FROM  (SELECT c.Color_key AS ShoeColor_key, c.Color_code AS ShoeColor_code, c.Description AS ShoeDescription, c.IsShoeColor AS ShoeIsShoeColor, 
                              c2.Color_key AS NonShoeColor_key, c2.Color_code AS NonShoeColor_code, c2.Description AS NonShoeDescription, 
                              c2.IsShoeColor AS NonShoeIsShoeColor
               FROM   dbo.Color AS c INNER JOIN
                              dbo.Color AS c2 ON c2.Color_code = c.Color_code AND c.IsShoeColor = 1 AND c2.IsShoeColor = 0 AND c.Description <> c2.Description) AS a
GO
