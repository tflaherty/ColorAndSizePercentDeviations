-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[DAI_EDA_ProductFromSKUKey2]
(	
	-- ToDo: Find out why this doesn't give us a record for all of our SKUs
	@SKUKey int
)
RETURNS TABLE 
AS
RETURN 
(
	select
		pr.*
	from SKU s
	inner join Item i ON i.Item_key = s.Item_fkey
	INNER join Color c ON c.Color_key = s.Color_fkey
	INNER join [Size] sz on sz.Size_key = s.Size_fkey
	INNER join MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr 
		on pr.INVENTORY = 'SY' 
		and cast(substring(pr.PARENT_PRODUCT, 1, 11) as INT) = i.Item_code 
		AND pr.id = pr.PARENT_PRODUCT + '-' + c.Color_code + '-' + sz.Size_code
	WHERE s.SKU_key = 268002 
	and pr.ID LIKE '[0-9][0-9][0-9][0-9]%-%'

)
GO
