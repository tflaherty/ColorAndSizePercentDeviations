CREATE VIEW [dbo].[BI_SKU]
AS
SELECT i.Item_code, c.Color_code, s.Size_code, sdst.Name AS DispStatus, CASE WHEN EXISTS
                   (SELECT ms.*
                    FROM   Media_SKU ms
                    WHERE ms.SKU_fkey = SKU.SKU_key AND ms.Media_fkey IN
                                       (SELECT m.Media_key
                                        FROM   Media m INNER JOIN
                                                       MediaType mt ON mt.MediaType_key = m.MediaType_fkey
                                        WHERE m.Season_fkey = dbo.ufGetCurrentSeasonKey() AND mt.Name = 'Regular')) THEN 1 ELSE 0 END AS NonClrMediaThisS, 
               CASE WHEN EXISTS
                   (SELECT ms.*
                    FROM   Media_SKU ms
                    WHERE ms.SKU_fkey = SKU.SKU_key AND ms.Media_fkey IN
                                       (SELECT m.Media_key
                                        FROM   Media m INNER JOIN
                                                       MediaType mt ON mt.MediaType_key = m.MediaType_fkey
                                        WHERE m.Season_fkey = dbo.ufGetCurrentSeasonKey() AND mt.Name = 'Clearance')) THEN 1 ELSE 0 END AS ClrMediaThisS, 
               CASE WHEN EXISTS
                   (SELECT ms.*
                    FROM   Media_SKU ms
                    WHERE ms.SKU_fkey = SKU.SKU_key AND ms.Media_fkey IN
                                       (SELECT m.Media_key
                                        FROM   Media m INNER JOIN
                                                       MediaType mt ON mt.MediaType_key = m.MediaType_fkey
                                        WHERE m.Season_fkey = dbo.ufGetNextSeasonKey() AND mt.Name = 'Regular')) THEN 1 ELSE 0 END AS NonClrMediaNextS, 
               CASE WHEN EXISTS
                   (SELECT ms.*
                    FROM   Media_SKU ms
                    WHERE ms.SKU_fkey = SKU.SKU_key AND ms.Media_fkey IN
                                       (SELECT m.Media_key
                                        FROM   Media m INNER JOIN
                                                       MediaType mt ON mt.MediaType_key = m.MediaType_fkey
                                        WHERE m.Season_fkey = dbo.ufGetCurrentSeasonKey() AND mt.Name = 'Clearance')) THEN 1 ELSE 0 END AS ClrMediaNextS
FROM  dbo.SKU INNER JOIN
               dbo.Item AS i ON i.Item_key = dbo.SKU.Item_fkey INNER JOIN
               dbo.Color AS c ON c.Color_key = dbo.SKU.Color_fkey INNER JOIN
               dbo.Size AS s ON s.Size_key = dbo.SKU.Size_fkey LEFT OUTER JOIN
               dbo.SKUDispositionStatusType AS sdst ON sdst.SKUDispositionStatusType_key = dbo.SKU.SKUDispositionStatusType_fkey
GO
