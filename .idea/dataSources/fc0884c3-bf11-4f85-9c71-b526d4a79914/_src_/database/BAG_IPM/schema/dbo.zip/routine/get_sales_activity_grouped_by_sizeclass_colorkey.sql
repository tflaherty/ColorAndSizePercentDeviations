






-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[get_sales_activity_grouped_by_sizeclass_colorkey] 
	-- Add the parameters for the stored procedure here
	(@ReferenceItemKey int,
	@MediaKey int )
AS
BEGIN
    -- THIS HAS TO BE HERE WHEN USING A TEMP TABLE IF YOU WANT VisualStudio 2008 to 
    -- be able to generate a TableAdapter from this StoredProcedure
	SET FMTONLY OFF;
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS
	(
		SELECT *
		FROM tempdb.dbo.sysobjects
		WHERE ID = OBJECT_ID(N'tempdb..#SizeClassTotals')
	)
	BEGIN
	DROP TABLE #SizeClassTotals
	END

	CREATE TABLE #SizeClassTotals
	(
		TotalGrossDemand int,
		TotalShipped int,
		TotalBackorders int,
		TotalCancellations int,
		TotalReturns int,
		SizeClassKey int,
		ItemKey int
	)

	INSERT INTO #SizeClassTotals 
	SELECT     SUM(sa.GrossDemandCount) AS TotalGrossDemand, 
               SUM(sa.ShippedSalesCount) AS TotalShipped, 
               SUM(sa.BackOrdersCount) AS TotalBackorders, 
			   SUM(sa.CancellationsCount) AS TotalCancellations, 
               SUM(sa.ReturnsCount) AS TotalReturns, Item.SizeClass_fkey, Item.Item_key
	FROM         SalesActivity AS sa INNER JOIN
						  SKU ON SKU.SKU_key = sa.SKU_fkey INNER JOIN
						  Item ON Item.Item_key = SKU.Item_fkey
	WHERE     (Item.ReferenceItem_fkey = @ReferenceItemKey) AND (sa.Media_fkey = @MediaKey)
	GROUP BY Item.SizeClass_fkey, Item.Item_key

	SELECT     ISNULL(SUM(CAST(sa.GrossDemandCount AS DECIMAL)/NULLIF(sct.TotalGrossDemand, 0)), 0) AS PercentGrossDemand, 
			   ISNULL(SUM(CAST(sa.ShippedSalesCount AS DECIMAL)/NULLIF(sct.TotalShipped, 0)), 0) AS PercentShipped, 
               ISNULL(SUM(CAST(sa.BackOrdersCount AS DECIMAL)/NULLIF(sct.TotalBackorders, 0)), 0) AS PercentBackorders, 
               ISNULL(SUM(CAST(sa.CancellationsCount AS DECIMAL)/NULLIF(sct.TotalCancellations, 0)), 0) AS PercentCancellations, 
               ISNULL(SUM(CAST(sa.ReturnsCount AS DECIMAL)/NULLIF(sct.TotalReturns, 0)), 0) AS PercentTotalReturns, 
			   SKU.Color_fkey, Item.SizeClass_fkey, Item.Item_key, sa.Media_fkey, Item.ReferenceItem_fkey, 
			   ISNULL(SUM(sa.GrossDemandCount), 0) AS GrossDemandCount,
			   ISNULL(SUM(sa.ShippedSalesCount), 0) AS ShippedSalesCount, 
			   ISNULL(SUM(sa.BackOrdersCount), 0) AS BackordersCount, 
			   ISNULL(SUM(sa.CancellationsCount), 0) AS CancellationsCount, 
			   ISNULL(SUM(sa.ReturnsCount), 0) AS ReturnsCount

	FROM         SalesActivity AS sa INNER JOIN
						  SKU ON SKU.SKU_key = sa.SKU_fkey INNER JOIN
						  Item ON Item.Item_key = SKU.Item_fkey INNER JOIN
				 #SizeClassTotals sct ON SCT.SizeClassKey = Item.SizeClass_fkey
	WHERE     (Item.ReferenceItem_fkey = @ReferenceItemKey) AND (sa.Media_fkey = @MediaKey)
	GROUP BY SKU.Color_fkey, Item.SizeClass_fkey, Item.Item_key, sa.Media_fkey, Item.ReferenceItem_fkey, 
             sct.TotalGrossDemand, sct.TotalShipped, sct.TotalBackorders, sct.TotalCancellations, sct.TotalReturns
	ORDER BY Item.SizeClass_fkey, SKU.Color_fkey


END


GO
