-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[usfMasterItemCodeFromReferenceItemKey] 
(
	-- Add the parameters for the function here
	@ReferenceItemKey int
)
RETURNS int
AS
BEGIN
	declare @MasterItemCode int

	select TOP 1 @MasterItemCode = 
	CASE
        WHEN EXISTS (select * from MasterItem_ReferenceItem miri where miri.ReferenceItem_fkey = @ReferenceItemKey)
        THEN (select top 1 mi.Item_code from MasterItem_ReferenceItem miri INNER join Item mi ON mi.Item_key = miri.Item_fkey where miri.ReferenceItem_fkey = @ReferenceItemKey ORDER by miri.Item_fkey)

		WHEN exists (select itm.Item_code
            FROM Item itm
            INNER JOIN SizeClass sc ON sc.SizeClass_key = itm.SizeClass_fkey
            WHERE sc.Name IN  ('MISSY','REGULAR','MEDIUM','ONE SIZE','32.0 Inseam')
            AND itm.ReferenceItem_fkey = @ReferenceItemKey)
		THEN
			(select top 1 itm.Item_code
            FROM Item itm
            INNER JOIN SizeClass sc ON sc.SizeClass_key = itm.SizeClass_fkey
            WHERE sc.Name IN  ('MISSY','REGULAR','MEDIUM','ONE SIZE','32.0 Inseam')
            AND itm.ReferenceItem_fkey = @ReferenceItemKey)
		ELSE 
			(select top 1 itm.Item_code
            FROM Item itm
            INNER JOIN SizeClass sc ON sc.SizeClass_key = itm.SizeClass_fkey
            AND itm.ReferenceItem_fkey = @ReferenceItemKey order by itm.Item_key)

	END 

	RETURN @MasterItemCode

END
GO
