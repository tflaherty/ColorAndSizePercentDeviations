-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SR_GetItemInfoBy_ItemCode] 
	-- Add the parameters for the stored procedure here
	(@ItemCode int)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select i.Item_code ItemCode, ri.Reference_code RefItemCode, ri.Description, d.Name Department, sc.Name SizeClass, div.Name Division, i.Item_key ItemKey, ri.ReferenceItem_key RefItemKey, d.Department_key DepartmentKey, sc.SizeClass_key SizeClassKey, div.Division_key DivisionKey  from Item i
	inner join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
	inner join Department d on d.Department_key = ri.Department_fkey
	inner join SizeClass sc on sc.SizeClass_key = i.SizeClass_fkey
	inner join Division div on div.Division_key = ri.Division_fkey
	where i.Item_code = @ItemCode
END
GO
