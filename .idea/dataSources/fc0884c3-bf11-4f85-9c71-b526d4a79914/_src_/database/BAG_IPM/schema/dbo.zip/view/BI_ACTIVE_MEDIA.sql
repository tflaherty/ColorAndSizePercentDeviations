CREATE VIEW [dbo].[BI_ACTIVE_MEDIA]
AS
SELECT     m.Media_code, dap.CatalogPageCount AS Space, m.Circulation, m.InHomeDate, m.ActivatedDate, m.InactivatedDate, 
                      dap.TotalCatalogGrossDemand AS PlanCatGDDollars, s.Season_code
FROM         dbo.Media AS m LEFT OUTER JOIN
                      dbo.DepartmentAssortmentPlan AS dap ON dap.Media_fkey = m.Media_key
                      LEFT OUTER JOIN dbo.Season AS s ON s.Season_key = m.Season_fkey
WHERE     (m.ActivatedDate <= CURRENT_TIMESTAMP) AND (m.InactivatedDate > CURRENT_TIMESTAMP)
GO
