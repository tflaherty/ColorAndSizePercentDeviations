CREATE VIEW [dbo].[LastAppearance]  
AS
SELECT ri.Reference_code, CAST(i.Item_code AS varchar(128)) + SPACE(1) + c.Color_code + SPACE(1) + sz.Size_code AS SKU,
                   (SELECT TOP (1) m.Media_code
                    FROM   dbo.Media_SKU AS ms INNER JOIN
                                   dbo.Media AS m ON m.Media_key = ms.Media_fkey INNER JOIN
                                   dbo.Season AS seas ON seas.Season_key = m.Season_fkey									
                    WHERE (ms.SKU_fkey = s.SKU_key and ms.Deleted = 0 AND m.Division_fkey = ri.Division_fkey)
                    ORDER BY m.ActivatedDate DESC) AS LastMedia,
                   (SELECT TOP (1) seas.Season_code
                    FROM   dbo.Media_SKU AS ms INNER JOIN
                                   dbo.Media AS m ON m.Media_key = ms.Media_fkey INNER JOIN
                                   dbo.Season AS seas ON seas.Season_key = m.Season_fkey
                    WHERE (ms.SKU_fkey = s.SKU_key and ms.Deleted = 0 AND m.Division_fkey = ri.Division_fkey)
                    ORDER BY m.ActivatedDate DESC) AS LastSeason
FROM  dbo.SKU AS s INNER JOIN
               dbo.Item AS i ON i.Item_key = s.Item_fkey INNER JOIN
               dbo.Color AS c ON c.Color_key = s.Color_fkey INNER JOIN
               dbo.Size AS sz ON sz.Size_key = s.Size_fkey INNER JOIN
               dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = i.ReferenceItem_fkey
GO
