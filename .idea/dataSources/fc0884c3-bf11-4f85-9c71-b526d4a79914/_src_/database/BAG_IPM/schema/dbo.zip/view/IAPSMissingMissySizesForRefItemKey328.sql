CREATE VIEW dbo.IAPSMissingMissySizesForRefItemKey328
AS
SELECT     iap.ItemAssortmentPlan_key, iap.Media_fkey, iap.ReferenceItem_fkey, iap.ColorPlan_fkey, iap.SizePlan_fkey, iap.PlanType_fkey, iap.PercentToAverageGross, 
                      iap.TrendPercentage, iap.TrendMedia_fkey, iap.PlanningMode_fkey, iap.ModelColorDescriptions, iap.ReturnRate, iap.Page, iap.TotalSpace, iap.ModelColor_fkey, 
                      iap.UseActualReturnRate, iap.UseActualColorPercentages, iap.UseActualSizePercentages, iap.Locked, iap.Deleted, iap.Comment, iap.SavedDate, iap.PlanGross, 
                      iap.PercentToBook, iap.GrossDemandUnitsUsingListPrice, iap.GrossDemandCentsPerCirc, iap.UseActualPercentToReferenceItems, m.Media_key, m.Media_code, 
                      m.MediaFormat_fkey, m.MediaType_fkey, m.Name, m.Description, m.MediaStatus_fkey, m.Season_fkey, m.OrderWithinSeason, m.Division_fkey, m.InHomeDate, 
                      m.ActivatedDate, m.InactivatedDate, m.Promo_fkey, m.Circulation, m.Priority, m.CurveStartDate, m.OldMedia_code, m.Quarter, m.InHomeDate2, 
                      m.LastYearsMedia_fkey, m.ParentMedia_fkey, m.ParentMediaRelationshipType_fkey, m.DefaultDemandCurve_fkey, pt.PlanType_key, pt.Name AS Expr1
FROM         dbo.ItemAssortmentPlan AS iap INNER JOIN
                      dbo.Media AS m ON m.Media_key = iap.Media_fkey INNER JOIN
                      dbo.PlanType AS pt ON pt.PlanType_key = iap.PlanType_fkey
WHERE     (iap.ReferenceItem_fkey = 328) AND (pt.Name = 'Current') AND (NOT EXISTS
                          (SELECT     spe.SizePlanEntry_key, spe.SizePlan_fkey, spe.Size_fkey, spe.PlannedPercentDemand, spe.Deleted, sz.Size_key, sz.Size_code, sz.SizeClass_fkey, 
                                                   sz.IsShoeSize, sz.SortOrder
                            FROM          dbo.SizePlanEntry AS spe INNER JOIN
                                                   dbo.Size AS sz ON sz.Size_key = spe.Size_fkey
                            WHERE      (spe.SizePlan_fkey = iap.SizePlan_fkey) AND (sz.SizeClass_fkey = 1) AND (spe.PlannedPercentDemand <> 0.0)))
GO
