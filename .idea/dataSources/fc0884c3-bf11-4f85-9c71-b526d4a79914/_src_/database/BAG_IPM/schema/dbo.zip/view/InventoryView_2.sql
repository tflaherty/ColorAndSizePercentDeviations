CREATE VIEW dbo.InventoryView_2
AS
SELECT     TOP (100) PERCENT div, dept, Item_code, Description, Size_code, SUM(TotalUnitsUnrestricted) AS TotalUnitsUnrestricted, SUM(TotalUnitsBlocked) 
                      AS TotalUnitsBlocked, SUM(TotalUnitsQA) AS TotalUnitsQA, SUM(TotalUnitsUnrestricted) + SUM(TotalUnitsBlocked) + SUM(TotalUnitsQA) AS TotalUnits, 
                      SUM(TotalUnitsUnrestricted * UnitCost) AS TotalCostUnrestricted, SUM(TotalUnitsBlocked * UnitCost) AS TotalCostBlocked, 
                      SUM(TotalUnitsQA * UnitCost) AS TotalCostQA, SUM(TotalUnitsUnrestricted * UnitCost) + SUM(TotalUnitsQA * UnitCost) 
                      + SUM(TotalUnitsBlocked * UnitCost) AS TotalCost, SUM(TotalUnitsUnrestricted * RegPrice) AS TotalPriceUnrestricted, 
                      SUM(TotalUnitsBlocked * RegPrice) AS TotalPriceBlocked, SUM(TotalUnitsQA * RegPrice) AS TotalPriceQA, SUM(TotalUnitsUnrestricted * RegPrice) 
                      + SUM(TotalUnitsQA * RegPrice) + SUM(TotalUnitsBlocked * RegPrice) AS TotalPrice
FROM         (SELECT     i.Item_code, ca.Description, sza.Size_code, d.Name AS dept, dv.Name AS div, sc.Cost AS UnitCost, SP.Price AS RegPrice,
                                                  (SELECT     i.UnitCount
                                                    FROM          dbo.Inventory AS i INNER JOIN
                                                                           dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey AND 
                                                                           ist.Name = 'Unrestricted' AND s.SKU_key = i.SKU_fkey) AS TotalUnitsUnrestricted,
                                                  (SELECT     i.UnitCount
                                                    FROM          dbo.Inventory AS i INNER JOIN
                                                                           dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey AND ist.Name = 'Blocked' AND 
                                                                           s.SKU_key = i.SKU_fkey) AS TotalUnitsBlocked,
                                                  (SELECT     i.UnitCount
                                                    FROM          dbo.Inventory AS i INNER JOIN
                                                                           dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey AND ist.Name = 'QA' AND 
                                                                           s.SKU_key = i.SKU_fkey) AS TotalUnitsQA
                       FROM          dbo.SKU AS s INNER JOIN
                                              dbo.Item AS i ON i.Item_key = s.Item_fkey INNER JOIN
                                              dbo.SKUCost AS sc ON sc.SKU_fkey = s.SKU_key INNER JOIN
                                              dbo.SKUCostType AS sct ON sct.SKUCostType_key = sc.SKUCostType_fkey AND sct.Name = 'MovingAverage' INNER JOIN
                                              dbo.SKUPrice AS SP ON SP.SKU_fkey = s.SKU_key INNER JOIN
                                              dbo.SKUPriceType AS spt ON spt.SKUPriceType_key = SP.SKUPriceType_fkey AND spt.Name = 'List' INNER JOIN
                                              dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = i.ReferenceItem_fkey INNER JOIN
                                              dbo.Department AS d ON d.Department_key = ri.Department_fkey INNER JOIN
                                              dbo.Division AS dv ON dv.Division_key = ri.Division_fkey INNER JOIN
                                              dbo.Color AS ca ON ca.Color_key = s.Color_fkey INNER JOIN
                                              dbo.Size AS sza ON sza.Size_key = s.Size_fkey) AS a
GROUP BY div, dept, Item_code, Description, Size_code, UnitCost, RegPrice WITH ROLLUP
HAVING      (SUM(TotalUnitsUnrestricted) > 0)
ORDER BY div, dept, Item_code, Description, Size_code
GO
