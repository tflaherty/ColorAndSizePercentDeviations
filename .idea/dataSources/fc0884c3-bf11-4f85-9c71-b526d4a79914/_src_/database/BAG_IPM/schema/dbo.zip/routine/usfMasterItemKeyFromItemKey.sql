-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[usfMasterItemKeyFromItemKey] 
(
	-- Add the parameters for the function here
	@ItemKey int
)
RETURNS int
AS
BEGIN
	declare @MasterItemKey int

	select TOP 1 @MasterItemKey = 
	CASE
        WHEN EXISTS (select * from Item i INNER join MasterItem_ReferenceItem miri on miri.ReferenceItem_fkey = i.ReferenceItem_fkey where i.Item_key = @ItemKey)
        THEN (select top 1 miri.Item_fkey from Item i INNER join MasterItem_ReferenceItem miri on miri.ReferenceItem_fkey = i.ReferenceItem_fkey where i.Item_key = @ItemKey ORDER by miri.Item_fkey)

		WHEN exists (select itm.Item_key
            FROM Item itm
            INNER JOIN SizeClass sc ON sc.SizeClass_key = itm.SizeClass_fkey
            WHERE sc.Name IN  ('MISSY','REGULAR','MEDIUM','ONE SIZE','32.0 Inseam')
            AND itm.ReferenceItem_fkey = (select top 1 Item.ReferenceItem_fkey FROM Item where Item.Item_key = @ItemKey))
		THEN
			(select top 1 itm.Item_key
            FROM Item itm
            INNER JOIN SizeClass sc ON sc.SizeClass_key = itm.SizeClass_fkey
            WHERE sc.Name IN  ('MISSY','REGULAR','MEDIUM','ONE SIZE','32.0 Inseam')
            AND itm.ReferenceItem_fkey = (select top 1 Item.ReferenceItem_fkey FROM Item where Item.Item_key = @ItemKey))
		ELSE 
			(select top 1 itm.Item_key
            FROM Item itm
            INNER JOIN SizeClass sc ON sc.SizeClass_key = itm.SizeClass_fkey
            AND itm.ReferenceItem_fkey = (select top 1 Item.ReferenceItem_fkey FROM Item where Item.Item_key = @ItemKey) order by itm.Item_key)

	END 

	RETURN @MasterItemKey
END
GO
