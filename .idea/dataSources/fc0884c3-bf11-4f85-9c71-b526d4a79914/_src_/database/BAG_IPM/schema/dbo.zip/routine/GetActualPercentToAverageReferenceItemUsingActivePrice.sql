-- =============================================
-- Author:		Thomas Flaherty
-- Create date: 8/13/2012
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[GetActualPercentToAverageReferenceItemUsingActivePrice]
(	
	@ReferenceItemKey int,
	@MediaKey int
)
RETURNS TABLE 
AS
RETURN 
(
	select
		a.*,
		CASE
			WHEN a.NumRefItemsInMedia is NOT NULL AND a.NumRefItemsInMedia > 0 THEN a.MediaTotalActivePriceGrossDemand/a.NumRefItemsInMedia
			ELSE 0
		END as ActualAverageRefItem,
		CASE
			WHEN a.MediaTotalActivePriceGrossDemand is NOT NULL AND a.MediaTotalActivePriceGrossDemand > 0 THEN (a.RefItemTotalActivePriceGrossDemand*a.NumRefItemsInMedia)/(a.MediaTotalActivePriceGrossDemand)
			ELSE 0
		END as ActualPercentToAverageRefItem


	from
	(select
		(select sum(gd.ActivePrice * gd.UnitCount) 
			from GrossDemand gd 
			inner join SKU s on s.SKU_key = gd.SKU_fkey 
			inner join Item i ON i.Item_key = s.Item_fkey 
			where gd.Media_fkey = @MediaKey and i.ReferenceItem_fkey = ri.ReferenceItem_key) as RefItemTotalActivePriceGrossDemand,
		(SELECT count(DISTINCT i.ReferenceItem_fkey) from Media_SKU ms INNER join Media m on m.Media_key = ms.Media_fkey inner JOIN SKU s on s.SKU_key = ms.SKU_fkey INNER join Item i on i.Item_key = s.Item_fkey where m.Media_key = @MediaKey and ms.Deleted = 0) as NumRefItemsInMedia,
		(select sum(gd.ActivePrice * gd.UnitCount) 
			from GrossDemand gd 
			inner join SKU s on s.SKU_key = gd.SKU_fkey 
			inner join Item i ON i.Item_key = s.Item_fkey 
			where gd.Media_fkey = @MediaKey) as MediaTotalActivePriceGrossDemand
		
	from ReferenceItem ri
	where ri.ReferenceItem_key = @ReferenceItemKey) as a)
GO
