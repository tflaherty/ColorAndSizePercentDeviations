CREATE VIEW [dbo].[VW_SelectTTASKUsNeedingSizeRemapping]
AS
SELECT     dbo.SKU.SKU_key, Size_fkey,
                          (SELECT     NewSizeKey
                            FROM          dbo.AllTTASKUSNeedingSizeRemapping
                            WHERE      (Size_code IN ('L', 'M', 'S', 'XL', 'XXL')) AND (NewSizeClassKey = 10) and dbo.SKU.SKU_key = dbo.AllTTASKUSNeedingSizeRemapping.sku_key) AS NewSizeKey
FROM         dbo.SKU
WHERE     EXISTS
                          (SELECT     Item_code, Color_code, Item_key, Color_key, Size_code, SizeSizeClass, ItemSizeClass, OldSizeClassKey, NewSizeClassKey, 
                                                   OldSizeKey, NewSizeKey, ReferenceItem_fkey
                            FROM          dbo.AllTTASKUSNeedingSizeRemapping
                            WHERE      (Size_code IN ('L', 'M', 'S', 'XL', 'XXL')) AND (NewSizeClassKey = 10) AND dbo.SKU.SKU_key = dbo.AllTTASKUSNeedingSizeRemapping.sku_key)
GO
