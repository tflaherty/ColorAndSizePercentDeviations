CREATE VIEW [dbo].[VW_AllTTASizePlanEntriesThatNeedChanging]
AS
SELECT  
	distinct TOP (100) PERCENT m.Media_code, vw.Size_code, vw.SizeSizeClass, vw.ItemSizeClass, spe.SizePlanEntry_key, vw.OldSizeKey, 
                      vw.NewSizeKey
FROM         dbo.ItemAssortmentPlan AS iap INNER JOIN
                      dbo.SizePlanEntry AS spe ON spe.SizePlan_fkey = iap.SizePlan_fkey INNER JOIN
                      (select distinct ReferenceItem_fkey, OldSizeKey, NewSizeKey, Size_code, SizeSizeClass, ItemSizeClass from AllTTASKUSNeedingSizeRemapping) AS vw ON vw.ReferenceItem_fkey = iap.ReferenceItem_fkey AND vw.OldSizeKey = spe.Size_fkey INNER JOIN
                      dbo.Media AS m ON m.Media_key = iap.Media_fkey
WHERE 1 = 1
and m.Division_fkey = 3
GO
