-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[InventoryHistoryTrigger] 
   ON  [dbo].[Inventory] 
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO dbo.InventoryHistory (SKU_fkey, UnitCount, InventoryDate, InventoryStatusType_fkey, AverageWeightedCost, [Date]) 
	SELECT SKU_fkey, UnitCount, InventoryDate, InventoryStatusType_fkey, AverageWeightedCost, GETDATE() from INSERTED;
END
GO
