-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[WebRankingGroup2Priority1] 
(	
	@DivisionCode varchar(255),
	@SortBy varchar(255),
	@MediaDaysForward int,
	@MediaDaysBack int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT
		b.*,
		CASE
			WHEN @SortBy = 'PlanUnits' THEN row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.PlanUnits desc)
			WHEN @SortBy = 'PlanDollars' THEN row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.PlanDollars desc)
			WHEN @SortBy = 'ProjectedDollars' THEN row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.ProjectedDollars desc)
			WHEN @SortBy = 'ProjectedUnits' THEN row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.ProjectedUnits desc)
		END as Ordinal
	from
	(SELECT
		a.Division_code,
		a.CategoryCode,
		a.CategoryName,
		(SELECT TOP 1 GENDER from dbo.DAI_EDA_FamilyLeaderRecordFromReferenceItemCode(a.Reference_code)) as GENDER,
		NULL as ClearanceFlags,
		a.ParentProductCode,
		a.Description,
		a.FirstAppearanceDateInSeason,
		sum(isnull(smfd.PlanUnits, 0.0)) as PlanUnits,
		sum(isnull(smfd.PlanDollars, 0.0)) as PlanDollars,
		sum(isnull(smfd.ProjectedUnits, 0.0)) as ProjectedUnits,
		sum(isnull(smfd.ProjectedDollars, 0.0)) as ProjectedDollars,
		sum(isnull(invsub.InventoryUnitCount, 0)) as InventoryUnits,	
		sum(isnull(posub.OnOrderUnitCount, 0)) as OnOrderUnits,
		sum(isnull(oversub.CurrentOverUnitCount, 0)) as CurrentOverUnits,	
		sum(isnull(undersub.CurrentUnderUnitCount, 0)) as CurrentUnderUnits,
		2 as [Group],
		NULL as GrossDemandUnits,
		NULL as GrossDemandDollars,
		a.ReferenceItem_key,
		1 as Priority
	from 
		(SELECT 
			ri.ReferenceItem_key,
			ri.Description,
			ri.Reference_code,
			pc.ParentProductCode,
			pc.CategoryCode,
			pc.CategoryName,
			pc.Division_code,
			(SELECT TOP 1 m2.Media_key from Media m2 
							inner join MediaFormat mf2 on mf2.MediaFormat_key = m2.MediaFormat_fkey
							inner join Media_SKU ms2 ON ms2.Media_fkey = m2.Media_key AND ms2.Deleted = 0
							inner join SKU s2 on s2.SKU_key = ms2.SKU_fkey 
							inner join Item i2 on i2.Item_key = s2.Item_fkey 
							WHERE mf2.Name = 'Print' and m2.Season_fkey = dbo.ufGetCurrentSeasonKey() and i2.ReferenceItem_fkey = ri.ReferenceItem_key
							order BY m2.InHomeDate asc) AS FirstAppearanceMediaInSeason,
			(SELECT TOP 1 m2.InHomeDate from Media m2 
							inner join MediaFormat mf2 on mf2.MediaFormat_key = m2.MediaFormat_fkey
							inner join Media_SKU ms2 ON ms2.Media_fkey = m2.Media_key AND ms2.Deleted = 0
							inner join SKU s2 on s2.SKU_key = ms2.SKU_fkey 
							inner join Item i2 on i2.Item_key = s2.Item_fkey 
							WHERE mf2.Name = 'Print' and m2.Season_fkey = dbo.ufGetCurrentSeasonKey() and i2.ReferenceItem_fkey = ri.ReferenceItem_key
							order BY m2.InHomeDate asc) AS FirstAppearanceDateInSeason
		from ReferenceItem ri
		inner join ProductCategory pc on pc.ParentProductCode = (SELECT top 1 pr2.ID from MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr2 where pr2.FAMILY_LEADER = 'Y' and pr2.INVENTORY = 'PP' AND pr2.FAMILY = ri.Reference_code order by pr2.ID)
		where cast(pc.Division_code as int) = CAST(@DivisionCode as int)) as a
	inner join Item i on i.ReferenceItem_fkey = a.ReferenceItem_key
	inner join SKU s ON s.Item_fkey = i.Item_key
	inner join Media_SKU ms on ms.SKU_fkey = s.SKU_key AND ms.Media_fkey = a.FirstAppearanceMediaInSeason and ms.Deleted = 0
	left outer join (SELECT SUM(inv.UnitCount) as InventoryUnitCount, inv.SKU_fkey from Inventory inv INNER join InventoryStatusType ist on ist.InventoryStatusType_key = inv.InventoryStatusType_fkey WHERE ist.Name = 'Unrestricted' GROUP BY inv.SKU_fkey) invsub on invsub.SKU_fkey = s.SKU_key
	left outer join (SELECT sum(pod.OpenQty) as OnOrderUnitCount, pod.SKU_fkey from PurchaseOrderDetail pod inner join PurchaseOrderMaster pom ON pom.PurchaseOrderMaster_key = pod.PurchaseOrderMaster_fkey where pod.DeliveryComplete = 0 GROUP BY pod.SKU_fkey) posub on posub.SKU_fkey = s.SKU_key
	left outer join (SELECT oum.CurrentOver as CurrentOverUnitCount, oum.SKU_fkey from OverUnderMaster oum) oversub on oversub.SKU_fkey = s.SKU_key
	left outer join (SELECT oum.CurrentUnder as CurrentUnderUnitCount, oum.SKU_fkey from OverUnderMaster oum) undersub on undersub.SKU_fkey = s.SKU_key
	left outer join SKUMediaForecastData smfd on smfd.SKU_fkey = s.SKU_key and smfd.Media_fkey = a.FirstAppearanceMediaInSeason
	where a.FirstAppearanceDateInSeason <= dateadd(day, @MediaDaysForward, getdate()) and a.FirstAppearanceDateInSeason >= dateadd(day, (@MediaDaysBack * -1), getdate())
	GROUP BY a.Division_code, a.ParentProductCode, a.CategoryCode, a.CategoryName, a.Reference_code, a.ReferenceItem_key, a.Description, a.FirstAppearanceDateInSeason) as b
)
GO
