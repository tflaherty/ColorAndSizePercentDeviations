-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION IsLastFullPriceAppearanceSeasonBy_SeasonKey_SKUKey
(

	@SeasonKey int,
	@SKUKey int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @TrueOrFalse int

	IF (SELECT dbo.usfLastFullPriceAppearanceSeasonKeyFromSKUKey(@SKUKey)) = @SeasonKey 
		SET @TrueOrFalse = 1
	ELSE
		SET @TrueOrFalse = 0

	RETURN @TrueOrFalse

END
GO
