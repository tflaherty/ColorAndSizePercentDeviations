CREATE VIEW [dbo].[DuplicateSKUs]
AS
select 
	(SELECT max(s.SKU_key) from SKU s) as MaxSKUKey,
	i.Item_code,
	ri.Reference_code,
	dep.Department_code,
	dep.Name,
	c.Color_code,
	c.IsShoeColor,
	c.Color_key,
	sz.Size_code,
	s.SKU_key as SKU_key ,
	(SELECT count(*) from Media_SKU ms WHERE ms.SKU_fkey = s.SKU_key) as MediaSKUCount,
	a.Item_code as _Item_code ,
	a.Color_code as _Color_code ,
	a.IsShoeColor as _IsShoeColor ,
	a.Color_key as _Color_key,
	a.Size_code as _Size_code ,
	a.SKU_key as _SKU_key,
	(SELECT count(*) from Media_SKU ms WHERE ms.SKU_fkey = a.SKU_key) as _MediaSKUCount
from SKU s
inner join Item i on i.Item_key = s.Item_fkey
inner join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
inner join Department dep on dep.Department_key = ri.Department_fkey
inner join Color c ON c.Color_key = s.Color_fkey
inner JOIN [Size] sz on sz.Size_key = s.Size_fkey
inner JOIN 
(select 
	s.Item_fkey,
	s.Size_fkey,
	i.Item_code,
	c.Color_code,
	c.IsShoeColor,
	c.Color_key,
	sz.Size_code,
	s.SKU_key 
from SKU s
inner join Item i on i.Item_key = s.Item_fkey
inner join Color c ON c.Color_key = s.Color_fkey
inner JOIN [Size] sz on sz.Size_key = s.Size_fkey
) as a on a.Color_code = c.Color_code and a.Item_fkey = i.Item_key AND a.Size_fkey = sz.Size_key and a.SKU_key != s.SKU_key and a.SKU_key > s.SKU_key
GO
