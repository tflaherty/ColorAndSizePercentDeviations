-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ufGetCurrentSeasonKey]
(
)
RETURNS int
AS
BEGIN
	declare @CurrentSeasonKey int

	SELECT     TOP (1) @CurrentSeasonKey = Season_key
	FROM         Season
	WHERE     (StartDate <= CURRENT_TIMESTAMP)
	ORDER BY StartDate DESC

	RETURN @CurrentSeasonKey

END
GO
