-- =============================================
-- Author:		Thomas Flaherty
-- Create date: Nov. 1, 2010
-- Description:	Gets the previous Season's key
-- =============================================
CREATE PROCEDURE [dbo].[GetPrevSeasonKeyBy_SeasonKey]
	-- Add the parameters for the stored procedure here
	@SeasonKey int,
    @PrevSeasonKey int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT    Top 1 @PrevSeasonKey = s2.Season_key 
	FROM         Season AS s1 INNER JOIN
						  Season AS s2 ON s1.StartDate > s2.StartDate 
	WHERE     (s1.Season_key = @SeasonKey)
	ORDER BY s2.StartDate DESC
END
GO
