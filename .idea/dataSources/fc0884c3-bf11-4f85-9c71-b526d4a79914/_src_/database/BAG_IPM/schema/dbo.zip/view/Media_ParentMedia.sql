CREATE VIEW [dbo].[Media_ParentMedia]
AS
SELECT dbo.Media.Media_code, Media_1.Media_code AS ParentMedia_code
FROM  dbo.Media LEFT OUTER JOIN
               dbo.Media AS Media_1 ON dbo.Media.ParentMedia_fkey = Media_1.Media_key
GO
