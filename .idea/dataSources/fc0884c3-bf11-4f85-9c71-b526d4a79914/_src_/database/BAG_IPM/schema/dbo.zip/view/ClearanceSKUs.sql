CREATE VIEW dbo.SKUandDisposition
AS
SELECT     CASE WHEN len(i.Item_code) < 6 THEN RIGHT('00000' + CAST(i.Item_code AS varchar(128)), 5) + SPACE(1) + c.Color_code + SPACE(1) 
                      + sz.Size_code COLLATE Latin1_General_BIN ELSE CAST(i.Item_code AS varchar(128)) + SPACE(1) + c.Color_code + SPACE(1) 
                      + sz.Size_code COLLATE Latin1_General_BIN END AS SKU, /*   sz.Size_code,*/ LEFT(sdt.Name, 1) AS DispCode
/*   si.Division_code */ FROM SKU s CROSS Apply SKUINFO(s.SKU_key) AS si INNER JOIN
                      Item i ON i.Item_key = s.Item_fkey INNER JOIN
                      Color c ON c.Color_key = s.Color_fkey INNER JOIN
                      [Size] sz ON sz.Size_key = s.Size_fkey INNER JOIN
                      SKUDispositionStatusType sdt ON sdt.SKUDispositionStatusType_key = s.SKUDispositionStatusType_fkey
WHERE     LEFT(sdt.Name, 1) = 'C'
/*Group By i.Item_code,
         c.Color_code,
         sz.Size_code,
         sdt.Name,
         si.Division_code
ORDER BY SKU*/
GO
