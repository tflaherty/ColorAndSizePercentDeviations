-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[GrossDemandPercentDoneByItemByMediaCode] 
(	
	@MediaCode varchar(100)
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT 
		d.*,
		d.CurvePercentDone - d.ActPercentDone as CurveMinusActPercentDone
	from
	(select 
		c.*,
		datename(dw,c.ActivityDate) as ActivityDayOfWeek,
		CASE
			WHEN c.ActivityDate >= c.CurveStartDate THEN 
				100*(select top 1 cve.[Value] from CurveEntry cve where cve.Curve_fkey = c.DemandCurveKey and cve.[Position] = datediff(day, c.CurveStartDate, c.ActivityDate))
		END as CurvePercentDone,
		datediff(day, c.CurveStartDate, c.ActivityDate) as DaysSinceCurveStart
	from
	(SELECT
		b.Item_code, b.ActivityDate, b.Media_fkey, b.DailyTotal, b.TtlUnitsSold, b.CurveStartDate, datediff(day, b.MinDate, b.MaxDate) as SalesDateSpan,
		cast(round((cast(b.RunningTotal as decimal)/cast(b.TtlUnitsSold as decimal)) * 100, 2) as decimal(5,2)) as ActPercentDone,
		cast(round((cast(b.DailyTotal as decimal)/cast(b.TtlUnitsSold as decimal)) * 100, 2) as decimal(5,2)) as ActIncPercentDone,
		b.DemandCurveKey
	from
	(select 
		a.*,
		sum(a.DailyTotal) OVER (PARTITION by a.Item_code, a.Media_fkey) as TtlUnitsSold,
		min(a.ActivityDate) over (Partition by a.Item_code, a.Media_fkey) as MinDate,
		max(a.ActivityDate) over (Partition by a.Item_code, a.Media_fkey) as MaxDate,
		(SELECT sum(gd2.UnitCount) from GrossDemand gd2 INNER JOIN SKU s2 ON s2.SKU_key = gd2.SKU_fkey inner join Item i2 on i2.Item_key = s2.Item_fkey WHERE i2.Item_code = a.Item_code and gd2.Media_fkey = a.Media_fkey and gd2.ActivityDate <= a.ActivityDate) as RunningTotal,
		(SELECT top 1 iapscd.DemandCurve_fkey from ItemAssortmentPlan iap inner join ItemAssortmentPlanSizeClassData iapscd on iapscd.ItemAssortmentPlan_fkey = iap.ItemAssortmentPlan_key where iap.Media_fkey = a.Media_fkey and iapscd.Item_fkey = a.Item_key) as DemandCurveKey

	from 
	(SELECT si.Item_code, si.Item_key, gd.ActivityDate, gd.Media_fkey, sum(gd.UnitCount) as DailyTotal, m.CurveStartDate FROM GrossDemand gd
	CROSS APPLY SKUInfo(gd.sku_fkey) as si
	INNER join Media m on m.Media_key = gd.Media_fkey
	where m.Media_code = @MediaCode
	group by gd.Media_fkey, si.Item_code, si.Item_key, gd.ActivityDate, m.CurveStartDate) as a) as b) as c) as d
	--order by d.TtlUnitsSold desc, d.Media_fkey, d.Item_code, d.ActivityDate
)
GO
