-- =============================================
-- Author:		Name
-- Create date: 
-- Description:	
-- =============================================
CREATE TRIGGER [dbo].[trg_User_CreatedDate_CreatedBy] 
   ON  [dbo].[User] 
   AFTER INSERT
AS 

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	SET Context_Info 0x55555 
	UPDATE [User] SET [User].CreatedDate=getdate(), [User].CreatedBy=SUSER_SNAME()
	FROM [User] INNER JOIN Inserted ON [User].[User_key]= Inserted.[User_key]

END
GO
