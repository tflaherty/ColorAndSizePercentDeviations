-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[DeleteSKUCompletelyFromDatabase] 
	@SKUKey int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	delete from SKUMediaSalesActivty_DW where SKUMediaSalesActivty_DW.SKU_fkey = @SKUKey
	delete from SKUSeasonalSalesActivty_DW where SKUSeasonalSalesActivty_DW.SKU_fkey = @SKUKey
	delete from SalesActivityMappingHistory where SalesActivityMappingHistory.SKU_fkey = @SKUKey
	delete from PurchaseOrderDetail WHERE PurchaseOrderDetail.SKU_fkey = @SKUKey
	delete from OverUnderMaster WHERE OverUnderMaster.SKU_fkey = @SKUKey
	delete from SKUMediaForecastData WHERE SKUMediaForecastData.SKU_fkey = @SKUKey
	delete from SKUCost WHERE SKUCost.SKU_fkey = @SKUKey
	delete from SKUPrice WHERE SKUPrice.SKU_fkey = @SKUKey
	delete from Media_SKU WHERE Media_SKU.SKU_fkey = @SKUKey
	delete from PurchaseOrder WHERE PurchaseOrder.SKU_fkey = @SKUKey
	delete from Inventory WHERE Inventory.SKU_fkey = @SKUKey
	delete from GrossDemand WHERE GrossDemand.SKU_fkey = @SKUKey
	delete from [Returns] WHERE [Returns].SKU_fkey = @SKUKey
	delete from Shipped WHERE Shipped.SKU_fkey = @SKUKey
	delete from Cancellations WHERE Cancellations.SKU_fkey = @SKUKey
	delete from BackOrders WHERE BackOrders.SKU_fkey = @SKUKey
	delete from RedcatsGrossDemand WHERE RedcatsGrossDemand.SKU_fkey = @SKUKey
	delete from RedcatsReturns WHERE RedcatsReturns.SKU_fkey = @SKUKey
	delete from RedcatsShipped WHERE RedcatsShipped.SKU_fkey = @SKUKey
	delete from RedcatsCancellations WHERE RedcatsCancellations.SKU_fkey = @SKUKey
	delete from RedcatsBackOrders WHERE RedcatsBackOrders.SKU_fkey = @SKUKey
	delete from SKU WHERE SKU.SKU_key = @SKUKey


END

GO
