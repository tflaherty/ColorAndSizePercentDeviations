CREATE FUNCTION [dbo].[UpsellRanking] 
(	
	@DeptCode varchar(255),
	@DivCode varchar(255),
    @MinPrice decimal,
	@MasterItemCodeToExclude int
)
RETURNS TABLE 
AS
RETURN 
(
SELECT ROW_NUMBER() 
        OVER(PARTITION BY C1.DivisionName, C1.Department_code ORDER BY sum(C1.DemandUnits)desc) AS Row,
       C1.Division_code,  
       C1.DivisionName,
       C1.Department_code,
       C1.MasterItemCode,
       C1.ReferenceItemName,
       C1.AVGPrice1,
       C1.AVGListPrice1,
       C1.DemandUnits,
       C1.OnHand1,
       C1.OnOrder1 

from

(SELECT B1.Division_code,
        B1.DivisionName,
        B1.MasterItemCode,
        B1.Department_code,
        B1.ReferenceItemName,
        Avg (B1.AVGPrice) as AvgPrice1,
        Avg (B1.AVGListPrice) as AvgListPrice1, 
        sum(B1.DemandUnits) as DemandUnits,
        sum (B1.OnHand)  as OnHand1,
        sum (B1.OnOrder) as OnOrder1

   FROM

(SELECT a1.Division_code, 
        a1.DivisionName,
  --      a1.ActivityDate,
        a1.MasterItemCode,
        a1.Department_code, 
  --      a1.Item_code,
  --      a1.Color_code,
  --      a1.Size_code,
  --      a1.Dispcode,
        a1.referenceItemName,
        a1.AVGPrice,
        a1.AVGListPrice,
        a1.DemandUnits,
        a1.OnHand,
        a1.OnOrder
       
 from

(SELECT si.Division_code, 
       si.DivisionName as DivisionName,
 --    gd.ActivityDate,
       dbo.usfMasterItemCodeFromReferenceItemKey(si.ReferenceItem_key) as MasterItemCode,
       si.referenceItemName,
       si.Department_code,
       si.Item_code,
       si.Color_code,
       si.Size_code,
--     sdt.Name as DispCode,
       sum (gd.UnitCount) as DemandUnits,
       avg (gd.ListPrice) as AVGPrice,
       avg (sp.price) as AVGListPrice,
       inv.UnitCount as OnHand,
       pod.OpenQty as OnOrder  
       
   FROM sku s 
Cross Apply SKUINFO(s.SKU_key) as si 
LEFT OUTER JOIN Inventory inv ON inv.SKU_fkey = s.SKU_key
       AND inv.InventoryStatusType_fkey = 4
LEFT Outer JOIN GrossDemand gd ON s.SKU_key = gd.SKU_fkey
INNER join SKUDispositionStatusType sdt ON sdt.SKUDispositionStatusType_key = s.SKUDispositionStatusType_fkey
LEFT Outer JOIN SKUPrice sp ON sp.SKU_fkey = s.SKU_key
    AND sp.SKUPriceType_fkey = 1 
     AND getdate () BETWEEN sp.StartDate AND sp.EndDate

LEFT OUTER JOIN PurchaseOrderDetail pod ON pod.SKU_fkey = s.SKU_key
      AND pod.DeliveryComplete = 0
       AND pod.OpenQty > 0
        AND (pod.CurrentDeliveryDate - getdate()) BETWEEN 0 AND 14


WHERE (gd.ActivityDate between DATEADD(day, DATEDIFF(day, 0, GETDATE()), -24) 
      and DATEADD(day, DATEDIFF(day, 0, GETDATE()), -6))
        OR 
       gd.ActivityDate IS null
        

GROUP BY si.Division_code,
         si.DivisionName,
 --        gd.ActivityDate,
         si.Department_code,
         si.Item_code,
         si.Color_code,
         si.Size_code,
         si.ReferenceItem_key,
         si.referenceItemName,
         inv.UnitCount,
         gd.ListPrice,
         pod.OpenQty 

) as a1) as B1

GROUP BY B1.Division_code,
         B1.DivisionName,
         B1.Department_code,
         B1.MasterItemCode,
         B1.ReferenceItemName  	
 --        B1.DispCode
          ) as C1 

WHERE C1.OnHand1 > 0
    OR C1.OnOrder1 > 0

GROUP BY C1.Division_code,
         C1.DivisionName,
         C1.Department_code,
         C1.MasterItemCode,
         C1.ReferenceItemName,
         C1.OnHand1,
         C1.AvgPrice1,
         C1.AvgListPrice1,
         C1.DemandUnits,
         C1.OnOrder1 
         

)
GO
