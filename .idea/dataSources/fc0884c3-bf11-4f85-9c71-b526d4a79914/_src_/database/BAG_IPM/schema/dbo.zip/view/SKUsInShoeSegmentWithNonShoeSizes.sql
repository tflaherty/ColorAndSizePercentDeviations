CREATE VIEW dbo.SKUsInShoeSegmentWithNonShoeSizes
AS
SELECT s.SKU_key, s.Item_fkey, s.Color_fkey, s.Size_fkey, s.SKUDispositionStatusType_fkey, s.SKUBackOrderDispositionStatusType_fkey, i.Item_key, i.Item_code, 
               i.ReferenceItem_fkey, i.SizeClass_fkey, c.Color_key, c.Color_code, c.Description, c.IsShoeColor, ri.ReferenceItem_key, ri.Reference_code, ri.Vendor_fkey, 
               ri.Class_fkey, ri.Department_fkey, ri.Division_fkey, ri.Description AS Expr1, ri.LinkToImage, ri.KeyItemType_fkey, ri.GoodBetterBestType_fkey, ri.Name, ri.Common, 
               dep.Department_key, dep.Department_code, dep.Segment_fkey, dep.Name AS Expr2, dep.Description AS Expr3, dep.EcometryDepartment_code, 
               seg.Segment_key, seg.Segment_code, seg.Category_fkey, seg.Name AS Expr4, seg.Description AS Expr5, seg.EcometrySegment_code, sz.Size_key, sz.Size_code, 
               sz.SizeClass_fkey AS Expr6, sz.IsShoeSize
FROM  dbo.SKU AS s INNER JOIN
               dbo.Item AS i ON i.Item_key = s.Item_fkey INNER JOIN
               dbo.Color AS c ON c.Color_key = s.Color_fkey INNER JOIN
               dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = i.ReferenceItem_fkey INNER JOIN
               dbo.Department AS dep ON dep.Department_key = ri.Department_fkey INNER JOIN
               dbo.Segment AS seg ON seg.Segment_key = dep.Segment_fkey INNER JOIN
               dbo.Size AS sz ON sz.Size_key = s.Size_fkey
WHERE (seg.Segment_code = 42) AND (sz.IsShoeSize = 0)
GO
