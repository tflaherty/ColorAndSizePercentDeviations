-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION usfLastFullPriceAppearanceSeasonKeyFromSKUKey
(
	@SKUKey int
)
RETURNS int
AS
BEGIN
	DECLARE @SeasonKey int

	select TOP 1 @SeasonKey = 
		CASE
			WHEN d.Division_code = 3 
				AND EXISTS (SELECT * FROM TTASKUsLastFPSeasonRemap lfpr WHERE lfpr.Item = cast(i.Item_code as VARCHAR) + ' ' + c.Color_code + ' ' + sz.Size_code) 
			THEN
				(select TOP 1 Season.Season_key from Season where Season.Season_code = 'F12')
			ELSE
			   (SELECT TOP 1 seas.Season_key from Media_SKU ms 
				inner join Media m on m.Media_key = ms.Media_fkey 
				inner join Season seas on seas.Season_key = m.Season_fkey 
				inner join MediaType mt ON mt.MediaType_key = m.MediaType_fkey 
				inner JOIN MediaFormat mf on mf.MediaFormat_key = m.MediaFormat_fkey
				where ms.SKU_fkey = s.SKU_key and ms.Deleted = 0 
				and mt.Name <> 'Clearance' AND m.Division_fkey = ri.Division_fkey
				ORDER by m.ActivatedDate desc)
		END
	from SKU s 
	inner join Item i on i.Item_key = s.Item_fkey
	inner join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
	inner join Division d on d.Division_key = ri.Division_fkey
	inner join Color c on c.Color_key = s.Color_fkey
	inner join Size sz on sz.Size_key = s.Size_fkey
	where s.SKU_key = @SKUKey

	RETURN @SeasonKey

END
GO
