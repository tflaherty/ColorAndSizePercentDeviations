CREATE VIEW dbo.SKUsWithAbnormalMinSKUPriceWithMoreThanOneSKUPriceRecord
AS
SELECT     TOP (100) PERCENT spt.Name AS PriceType, div.Division_code, dep.Department_code, ri.Reference_code, i.Item_code, MIN(sp.Price) AS minPrice, 
                      MAX(sp.Price) AS maxPrice, COUNT(*) AS NumSKUPriceRecords, s.SKU_key, i.Item_key, ri.ReferenceItem_key, dep.Department_key, 
                      div.Division_key
FROM         dbo.SKUPrice AS sp INNER JOIN
                      dbo.SKU AS s ON s.SKU_key = sp.SKU_fkey INNER JOIN
                      dbo.SKUPriceType AS spt ON spt.SKUPriceType_key = sp.SKUPriceType_fkey INNER JOIN
                      dbo.Item AS i ON i.Item_key = s.Item_fkey INNER JOIN
                      dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = i.ReferenceItem_fkey INNER JOIN
                      dbo.Department AS dep ON dep.Department_key = ri.Department_fkey INNER JOIN
                      dbo.Division AS div ON div.Division_key = ri.Division_fkey
GROUP BY s.SKU_key, i.Item_code, ri.Reference_code, spt.Name, i.Item_key, ri.ReferenceItem_key, dep.Department_code, dep.Department_key, 
                      div.Division_key, div.Division_code
HAVING      (COUNT(*) > 1) AND (MIN(sp.Price) < 12.99) AND (MIN(sp.Price) <> MAX(sp.Price))
ORDER BY PriceType, div.Division_code, dep.Department_code, ri.Reference_code, i.Item_code, s.SKU_key
GO
