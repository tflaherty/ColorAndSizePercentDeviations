-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ProcessAfterEcometryFullImport] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
BEGIN TRY
	TRUNCATE TABLE SKUSeasonalSalesActivty_DW
	INSERT INTO SKUSeasonalSalesActivty_DW
	Select
		a.Season_code,
		a.Reference_code,
		a.Item_code,
		a.Color_code,
		a.Size_code,

		CASE
			WHEN a.SKU_ShippedUnits is not NULL and a.SKU_ReturnedUnits is not NULL THEN cast(a.SKU_ReturnedUnits as DECIMAL)/cast(a.SKU_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as SKU_ReturnRate,
		CASE
			WHEN a.ItemColor_ShippedUnits is not NULL and a.ItemColor_ReturnedUnits is not NULL THEN cast(a.ItemColor_ReturnedUnits as DECIMAL)/cast(a.ItemColor_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as ItemColor_ReturnRate,
		CASE
			WHEN a.ItemSize_ShippedUnits is not NULL and a.ItemSize_ReturnedUnits is not NULL THEN cast(a.ItemSize_ReturnedUnits as DECIMAL)/cast(a.ItemSize_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as ItemSize_ReturnRate,
		CASE
			WHEN a.Item_ShippedUnits is not NULL and a.Item_ReturnedUnits is not NULL THEN cast(a.Item_ReturnedUnits as DECIMAL)/cast(a.Item_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as Item_ReturnRate,
		CASE
			WHEN a.ReferenceItem_ShippedUnits is not NULL and a.ReferenceItem_ReturnedUnits is not NULL THEN cast(a.ReferenceItem_ReturnedUnits as DECIMAL)/cast(a.ReferenceItem_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as ReferenceItem_ReturnRate,
		CASE
			WHEN a.SKU_GrossDemandUnits is not NULL and a.SKU_CancelledUnits is not NULL THEN cast(a.SKU_CancelledUnits as DECIMAL)/cast(a.SKU_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_CancellationRate,
		CASE
			WHEN a.ItemColor_GrossDemandUnits is not NULL and a.ItemColor_CancelledUnits is not NULL THEN cast(a.ItemColor_CancelledUnits as DECIMAL)/cast(a.ItemColor_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as ItemColor_CancellationRate,
		CASE
			WHEN a.ItemSize_GrossDemandUnits is not NULL and a.ItemSize_CancelledUnits is not NULL THEN cast(a.ItemSize_CancelledUnits as DECIMAL)/cast(a.ItemSize_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as ItemSize_CancellationRate,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.Item_CancelledUnits is not NULL THEN cast(a.Item_CancelledUnits as DECIMAL)/cast(a.Item_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as Item_CancellationRate,
		CASE
			WHEN a.ReferenceItem_GrossDemandUnits is not NULL and a.ReferenceItem_CancelledUnits is not NULL THEN cast(a.ReferenceItem_CancelledUnits as DECIMAL)/cast(a.ReferenceItem_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as ReferenceItem_CancellationRate,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.ItemSize_GrossDemandUnits is not NULL THEN cast(a.ItemSize_GrossDemandUnits as DECIMAL)/cast(a.Item_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SizePlanPercent,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.ItemColor_GrossDemandUnits is not NULL THEN cast(a.ItemColor_GrossDemandUnits as DECIMAL)/cast(a.Item_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as ColorPlanPercent,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.ReferenceItem_GrossDemandUnits is not NULL THEN cast(a.Item_GrossDemandUnits as DECIMAL)/cast(a.ReferenceItem_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as Item_PercentToReferenceItem,
		CASE
			WHEN a.ItemColor_GrossDemandUnits is not NULL and a.SKU_GrossDemandUnits is not NULL THEN cast(a.SKU_GrossDemandUnits as DECIMAL)/cast(a.ItemColor_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_PercentToItemColor,
		CASE
			WHEN a.ItemSize_GrossDemandUnits is not NULL and a.SKU_GrossDemandUnits is not NULL THEN cast(a.SKU_GrossDemandUnits as DECIMAL)/cast(a.ItemSize_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_PercentToItemSize,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.SKU_GrossDemandUnits is not NULL THEN cast(a.SKU_GrossDemandUnits as DECIMAL)/cast(a.Item_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_PercentToItem,
		CASE
			WHEN a.ReferenceItem_GrossDemandUnits is not NULL and a.SKU_GrossDemandUnits is not NULL THEN cast(a.SKU_GrossDemandUnits as DECIMAL)/cast(a.ReferenceItem_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_PercentToReferenceItem,

		a.Season_fkey,
		a.ReferenceItem_fkey,
		a.Item_fkey,
		a.Color_fkey,
		a.Size_fkey,
		a.SKU_fkey,

		ISNULL(a.SKU_GrossDemandUnits, 0),
		ISNULL(a.ItemColor_GrossDemandUnits, 0),
		ISNULL(a.ItemSize_GrossDemandUnits, 0),
		ISNULL(a.Item_GrossDemandUnits, 0),
		ISNULL(a.ReferenceItem_GrossDemandUnits, 0),

		ISNULL(a.SKU_GrossDemandListPrice, 0),
		ISNULL(a.ItemColor_GrossDemandListPrice, NULL),
		ISNULL(a.ItemSize_GrossDemandListPrice, NULL),
		ISNULL(a.Item_GrossDemandListPrice, 0),
		ISNULL(a.ReferenceItem_GrossDemandListPrice, 0),

		ISNULL(a.SKU_GrossDemandActivePrice, 0),
		ISNULL(a.ItemColor_GrossDemandActivePrice, NULL),
		ISNULL(a.ItemSize_GrossDemandActivePrice, NULL),
		ISNULL(a.Item_GrossDemandActivePrice, 0),
		ISNULL(a.ReferenceItem_GrossDemandActivePrice, 0),

		ISNULL(a.SKU_GrossDemandFinalSellingPrice, 0),
		ISNULL(a.ItemColor_GrossDemandFinalSellingPrice, NULL),
		ISNULL(a.ItemSize_GrossDemandFinalSellingPrice, NULL),
		ISNULL(a.Item_GrossDemandFinalSellingPrice, 0),
		ISNULL(a.ReferenceItem_GrossDemandFinalSellingPrice, 0),

		ISNULL(a.SKU_ShippedUnits, 0),
		ISNULL(a.ItemColor_ShippedUnits, NULL),
		ISNULL(a.ItemSize_ShippedUnits, NULL),
		ISNULL(a.Item_ShippedUnits, 0),
		ISNULL(a.ReferenceItem_ShippedUnits, 0),

		ISNULL(a.SKU_ShippedListPrice, 0),
		ISNULL(a.ItemColor_ShippedListPrice, NULL),
		ISNULL(a.ItemSize_ShippedListPrice, NULL),
		ISNULL(a.Item_ShippedListPrice, 0),
		ISNULL(a.ReferenceItem_ShippedListPrice, 0),

		ISNULL(a.SKU_ShippedActivePrice, 0),
		ISNULL(a.ItemColor_ShippedActivePrice, NULL),
		ISNULL(a.ItemSize_ShippedActivePrice, NULL),
		ISNULL(a.Item_ShippedActivePrice, 0),
		ISNULL(a.ReferenceItem_ShippedActivePrice, 0),

		ISNULL(a.SKU_ShippedFinalSellingPrice, 0),
		ISNULL(a.ItemColor_ShippedFinalSellingPrice, NULL),
		ISNULL(a.ItemSize_ShippedFinalSellingPrice, NULL),
		ISNULL(a.Item_ShippedFinalSellingPrice, 0),
		ISNULL(a.ReferenceItem_ShippedFinalSellingPrice, 0),

		ISNULL(a.SKU_ReturnedUnits, 0),
		ISNULL(a.ItemColor_ReturnedUnits, NULL),
		ISNULL(a.ItemSize_ReturnedUnits, NULL),
		ISNULL(a.Item_ReturnedUnits, 0),
		ISNULL(a.ReferenceItem_ReturnedUnits, 0),

		ISNULL(a.SKU_ReturnedListPrice, 0),
		ISNULL(a.ItemColor_ReturnedListPrice, NULL),
		ISNULL(a.ItemSize_ReturnedListPrice, NULL),
		ISNULL(a.Item_ReturnedListPrice, 0),
		ISNULL(a.ReferenceItem_ReturnedListPrice, 0),

		ISNULL(a.SKU_ReturnedActivePrice, 0),
		ISNULL(a.ItemColor_ReturnedActivePrice, NULL),
		ISNULL(a.ItemSize_ReturnedActivePrice, NULL),
		ISNULL(a.Item_ReturnedActivePrice, 0),
		ISNULL(a.ReferenceItem_ReturnedActivePrice, 0),

		ISNULL(a.SKU_ReturnedFinalSellingPrice, 0),
		ISNULL(a.ItemColor_ReturnedFinalSellingPrice, NULL),
		ISNULL(a.ItemSize_ReturnedFinalSellingPrice, NULL),
		ISNULL(a.Item_ReturnedFinalSellingPrice, 0),
		ISNULL(a.ReferenceItem_ReturnedFinalSellingPrice, 0),

		ISNULL(a.SKU_CancelledUnits, 0),
		ISNULL(a.ItemColor_CancelledUnits, NULL),
		ISNULL(a.ItemSize_CancelledUnits, NULL),
		ISNULL(a.Item_CancelledUnits, 0),
		ISNULL(a.ReferenceItem_CancelledUnits, 0),

		ISNULL(a.SKU_CancelledListPrice, 0),
		ISNULL(a.ItemColor_CancelledListPrice, NULL),
		ISNULL(a.ItemSize_CancelledListPrice, NULL),
		ISNULL(a.Item_CancelledListPrice, 0),
		ISNULL(a.ReferenceItem_CancelledListPrice, 0),

		ISNULL(a.SKU_CancelledActivePrice, 0),
		ISNULL(a.ItemColor_CancelledActivePrice, NULL),
		ISNULL(a.ItemSize_CancelledActivePrice, NULL),
		ISNULL(a.Item_CancelledActivePrice, 0),
		ISNULL(a.ReferenceItem_CancelledActivePrice, 0),

		ISNULL(a.SKU_CancelledFinalSellingPrice, 0),
		ISNULL(a.ItemColor_CancelledFinalSellingPrice, NULL),
		ISNULL(a.ItemSize_CancelledFinalSellingPrice, NULL),
		ISNULL(a.Item_CancelledFinalSellingPrice, 0),
		ISNULL(a.ReferenceItem_CancelledFinalSellingPrice, 0)

	from
	(SELECT
		s.SKU_key as SKU_fkey,
		i.ReferenceItem_fkey,
		ri.Reference_code,
		s.Item_fkey,
		i.Item_code,
		s.Color_fkey,
		c.Color_code,
		s.Size_fkey,
		sz.Size_code,
		seas.Season_key as Season_fkey,
		seas.Season_code,

		sku_gd.SKU_GrossDemandUnits,
		sku_gd.SKU_GrossDemandListPrice,
		sku_gd.SKU_GrossDemandActivePrice,
		sku_gd.SKU_GrossDemandFinalSellingPrice,
		sku_ca.SKU_CancelledUnits,
		sku_ca.SKU_CancelledListPrice,
		sku_ca.SKU_CancelledActivePrice,
		sku_ca.SKU_CancelledFinalSellingPrice,
		sku_re.SKU_ReturnedUnits,
		sku_re.SKU_ReturnedListPrice,
		sku_re.SKU_ReturnedActivePrice,
		sku_re.SKU_ReturnedFinalSellingPrice,
		sku_sh.SKU_ShippedUnits,
		sku_sh.SKU_ShippedListPrice,
		sku_sh.SKU_ShippedActivePrice,
		sku_sh.SKU_ShippedFinalSellingPrice,


		itemColor_gd.ItemColor_GrossDemandUnits,
	/*
		itemColor_gd.ItemColor_GrossDemandListPrice,
		itemColor_gd.ItemColor_GrossDemandActivePrice,
		itemColor_gd.ItemColor_GrossDemandFinalSellingPrice,
		itemColor_ca.ItemColor_CancelledUnits,
		itemColor_ca.ItemColor_CancelledListPrice,
		itemColor_ca.ItemColor_CancelledActivePrice,
		itemColor_ca.ItemColor_CancelledFinalSellingPrice,
		itemColor_re.ItemColor_ReturnedUnits,
		itemColor_re.ItemColor_ReturnedListPrice,
		itemColor_re.ItemColor_ReturnedActivePrice,
		itemColor_re.ItemColor_ReturnedFinalSellingPrice,
		itemColor_sh.ItemColor_ShippedUnits,
		itemColor_sh.ItemColor_ShippedListPrice,
		itemColor_sh.ItemColor_ShippedActivePrice,
		itemColor_sh.ItemColor_ShippedFinalSellingPrice,
	*/
		NULL as ItemColor_GrossDemandListPrice,
		NULL as ItemColor_GrossDemandActivePrice,
		NULL as ItemColor_GrossDemandFinalSellingPrice,
		NULL as ItemColor_CancelledUnits,
		NULL as ItemColor_CancelledListPrice,
		NULL as ItemColor_CancelledActivePrice,
		NULL as ItemColor_CancelledFinalSellingPrice,
		NULL as ItemColor_ReturnedUnits,
		NULL as ItemColor_ReturnedListPrice,
		NULL as ItemColor_ReturnedActivePrice,
		NULL as ItemColor_ReturnedFinalSellingPrice,
		NULL as ItemColor_ShippedUnits,
		NULL as ItemColor_ShippedListPrice,
		NULL as ItemColor_ShippedActivePrice,
		NULL as ItemColor_ShippedFinalSellingPrice,


		itemSize_gd.ItemSize_GrossDemandUnits,
	/*
		itemSize_gd.ItemSize_GrossDemandListPrice,
		itemSize_gd.ItemSize_GrossDemandActivePrice,
		itemSize_gd.ItemSize_GrossDemandFinalSellingPrice,
		itemSize_ca.ItemSize_CancelledUnits,
		itemSize_ca.ItemSize_CancelledListPrice,
		itemSize_ca.ItemSize_CancelledActivePrice,
		itemSize_ca.ItemSize_CancelledFinalSellingPrice,
		itemSize_re.ItemSize_ReturnedUnits,
		itemSize_re.ItemSize_ReturnedListPrice,
		itemSize_re.ItemSize_ReturnedActivePrice,
		itemSize_re.ItemSize_ReturnedFinalSellingPrice,
		itemSize_sh.ItemSize_ShippedUnits,
		itemSize_sh.ItemSize_ShippedListPrice,
		itemSize_sh.ItemSize_ShippedActivePrice,
		itemSize_sh.ItemSize_ShippedFinalSellingPrice,
	*/
		NULL as ItemSize_GrossDemandListPrice,
		NULL as ItemSize_GrossDemandActivePrice,
		NULL as ItemSize_GrossDemandFinalSellingPrice,
		NULL as ItemSize_CancelledUnits,
		NULL as ItemSize_CancelledListPrice,
		NULL as ItemSize_CancelledActivePrice,
		NULL as ItemSize_CancelledFinalSellingPrice,
		NULL as ItemSize_ReturnedUnits,
		NULL as ItemSize_ReturnedListPrice,
		NULL as ItemSize_ReturnedActivePrice,
		NULL as ItemSize_ReturnedFinalSellingPrice,
		NULL as ItemSize_ShippedUnits,
		NULL as ItemSize_ShippedListPrice,
		NULL as ItemSize_ShippedActivePrice,
		NULL as ItemSize_ShippedFinalSellingPrice,

		item_gd.Item_GrossDemandUnits,
		item_gd.Item_GrossDemandListPrice,
		item_gd.Item_GrossDemandActivePrice,
		item_gd.Item_GrossDemandFinalSellingPrice,
		item_ca.Item_CancelledUnits,
		item_ca.Item_CancelledListPrice,
		item_ca.Item_CancelledActivePrice,
		item_ca.Item_CancelledFinalSellingPrice,
		item_re.Item_ReturnedUnits,
		item_re.Item_ReturnedListPrice,
		item_re.Item_ReturnedActivePrice,
		item_re.Item_ReturnedFinalSellingPrice,
		item_sh.Item_ShippedUnits,
		item_sh.Item_ShippedListPrice,
		item_sh.Item_ShippedActivePrice,
		item_sh.Item_ShippedFinalSellingPrice,

		ri_gd.ReferenceItem_GrossDemandUnits,
		ri_gd.ReferenceItem_GrossDemandListPrice,
		ri_gd.ReferenceItem_GrossDemandActivePrice,
		ri_gd.ReferenceItem_GrossDemandFinalSellingPrice,
		ri_ca.ReferenceItem_CancelledUnits,
		ri_ca.ReferenceItem_CancelledListPrice,
		ri_ca.ReferenceItem_CancelledActivePrice,
		ri_ca.ReferenceItem_CancelledFinalSellingPrice,
		ri_re.ReferenceItem_ReturnedUnits,
		ri_re.ReferenceItem_ReturnedListPrice,
		ri_re.ReferenceItem_ReturnedActivePrice,
		ri_re.ReferenceItem_ReturnedFinalSellingPrice,
		ri_sh.ReferenceItem_ShippedUnits,
		ri_sh.ReferenceItem_ShippedListPrice,
		ri_sh.ReferenceItem_ShippedActivePrice,
		ri_sh.ReferenceItem_ShippedFinalSellingPrice


	from SKU s
	inner join Item i on i.Item_key = s.Item_fkey
	inner join Color c on c.Color_key = s.Color_fkey
	inner JOIN Size sz on sz.Size_key = s.Size_fkey
	INNER join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
	cross JOIN Season seas

	LEFT OUTER JOIN (select sum(UnitCount) as SKU_GrossDemandUnits, sum(ListPrice*UnitCount) as SKU_GrossDemandListPrice, sum(ActivePrice*UnitCount) as SKU_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as SKU_GrossDemandFinalSellingPrice, SKU_fkey, Season_fkey from GrossDemand   inner join Media on Media_fkey = Media_key group BY GrossDemand.SKU_fkey,   Media.Season_fkey) as sku_gd on sku_gd.SKU_fkey = s.SKU_key and sku_gd.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as SKU_ShippedUnits, sum(ListPrice*UnitCount) as SKU_ShippedListPrice, sum(ActivePrice*UnitCount) as SKU_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as SKU_ShippedFinalSellingPrice,     SKU_fkey, Season_fkey from Shipped       inner join Media on Media_fkey = Media_key group BY Shipped.SKU_fkey,       Media.Season_fkey) as sku_sh on sku_sh.SKU_fkey = s.SKU_key and sku_sh.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as SKU_CancelledUnits, sum(ListPrice*UnitCount) as SKU_CancelledListPrice, sum(ActivePrice*UnitCount) as SKU_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as SKU_CancelledFinalSellingPrice,   SKU_fkey, Season_fkey from Cancellations inner join Media on Media_fkey = Media_key group BY Cancellations.SKU_fkey, Media.Season_fkey) as sku_ca on sku_ca.SKU_fkey = s.SKU_key and sku_ca.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as SKU_ReturnedUnits, sum(ListPrice*UnitCount) as SKU_ReturnedListPrice, sum(ActivePrice*UnitCount) as SKU_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as SKU_ReturnedFinalSellingPrice,      SKU_fkey, Season_fkey from Returns       inner join Media on Media_fkey = Media_key group BY Returns.SKU_fkey,       Media.Season_fkey) as sku_re on sku_re.SKU_fkey = s.SKU_key and sku_re.Season_fkey = seas.Season_key


	LEFT OUTER JOIN (select sum(UnitCount) as ItemColor_GrossDemandUnits, sum(ListPrice*UnitCount) as ItemColor_GrossDemandListPrice, sum(ActivePrice*UnitCount) as ItemColor_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as ItemColor_GrossDemandFinalSellingPrice, SKU.Item_fkey, SKU.Color_fkey, Season_fkey from GrossDemand   inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = GrossDemand.SKU_fkey   group BY SKU.Item_fkey, SKU.Color_fkey, Media.Season_fkey) as itemColor_gd on itemColor_gd.Item_fkey = s.Item_fkey AND itemColor_gd.Color_fkey = s.Color_fkey and itemColor_gd.Season_fkey = seas.Season_key
	/*
	LEFT OUTER JOIN (select sum(UnitCount) as ItemColor_ShippedUnits, sum(ListPrice*UnitCount) as ItemColor_ShippedListPrice, sum(ActivePrice*UnitCount) as ItemColor_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as ItemColor_ShippedFinalSellingPrice,     SKU.Item_fkey, SKU.Color_fkey, Season_fkey from Shipped       inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Shipped.SKU_fkey       group BY SKU.Item_fkey, SKU.Color_fkey, Media.Season_fkey) as itemColor_sh on itemColor_sh.Item_fkey = s.Item_fkey AND itemColor_sh.Color_fkey = s.Color_fkey and itemColor_sh.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as ItemColor_CancelledUnits, sum(ListPrice*UnitCount) as ItemColor_CancelledListPrice, sum(ActivePrice*UnitCount) as ItemColor_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as ItemColor_CancelledFinalSellingPrice,   SKU.Item_fkey, SKU.Color_fkey, Season_fkey from Cancellations inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Cancellations.SKU_fkey group BY SKU.Item_fkey, SKU.Color_fkey, Media.Season_fkey) as itemColor_ca on itemColor_ca.Item_fkey = s.Item_fkey AND itemColor_ca.Color_fkey = s.Color_fkey and itemColor_ca.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as ItemColor_ReturnedUnits, sum(ListPrice*UnitCount) as ItemColor_ReturnedListPrice, sum(ActivePrice*UnitCount) as ItemColor_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as ItemColor_ReturnedFinalSellingPrice,    SKU.Item_fkey, SKU.Color_fkey, Season_fkey from Returns       inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Returns.SKU_fkey       group BY SKU.Item_fkey, SKU.Color_fkey, Media.Season_fkey) as itemColor_re on itemColor_re.Item_fkey = s.Item_fkey AND itemColor_re.Color_fkey = s.Color_fkey and itemColor_re.Season_fkey = seas.Season_key
	*/

	LEFT OUTER JOIN (select sum(UnitCount) as ItemSize_GrossDemandUnits, sum(ListPrice*UnitCount) as ItemSize_GrossDemandListPrice, sum(ActivePrice*UnitCount) as ItemSize_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as ItemSize_GrossDemandFinalSellingPrice, SKU.Item_fkey, SKU.Size_fkey, Season_fkey from GrossDemand   inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = GrossDemand.SKU_fkey group BY SKU.Item_fkey, SKU.Size_fkey, Media.Season_fkey) as ItemSize_gd on ItemSize_gd.Item_fkey = s.Item_fkey AND ItemSize_gd.Size_fkey = s.Size_fkey and ItemSize_gd.Season_fkey = seas.Season_key
	/*
	LEFT OUTER JOIN (select sum(UnitCount) as ItemSize_ShippedUnits, sum(ListPrice*UnitCount) as ItemSize_ShippedListPrice, sum(ActivePrice*UnitCount) as ItemSize_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as ItemSize_ShippedFinalSellingPrice,     SKU.Item_fkey, SKU.Size_fkey, Season_fkey from Shipped       inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Shipped.SKU_fkey group BY SKU.Item_fkey, SKU.Size_fkey, Media.Season_fkey) as ItemSize_sh on ItemSize_sh.Item_fkey = s.Item_fkey AND ItemSize_sh.Size_fkey = s.Size_fkey and ItemSize_sh.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as ItemSize_CancelledUnits, sum(ListPrice*UnitCount) as ItemSize_CancelledListPrice, sum(ActivePrice*UnitCount) as ItemSize_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as ItemSize_CancelledFinalSellingPrice,   SKU.Item_fkey, SKU.Size_fkey, Season_fkey from Cancellations inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Cancellations.SKU_fkey group BY SKU.Item_fkey, SKU.Size_fkey, Media.Season_fkey) as ItemSize_ca on ItemSize_ca.Item_fkey = s.Item_fkey AND ItemSize_ca.Size_fkey = s.Size_fkey and ItemSize_ca.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as ItemSize_ReturnedUnits, sum(ListPrice*UnitCount) as ItemSize_ReturnedListPrice, sum(ActivePrice*UnitCount) as ItemSize_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as ItemSize_ReturnedFinalSellingPrice,    SKU.Item_fkey, SKU.Size_fkey, Season_fkey from Returns       inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Returns.SKU_fkey group BY SKU.Item_fkey, SKU.Size_fkey, Media.Season_fkey) as ItemSize_re on ItemSize_re.Item_fkey = s.Item_fkey AND ItemSize_re.Size_fkey = s.Size_fkey and ItemSize_re.Season_fkey = seas.Season_key
	*/

	LEFT OUTER JOIN (select sum(UnitCount) as Item_GrossDemandUnits, sum(ListPrice*UnitCount) as Item_GrossDemandListPrice, sum(ActivePrice*UnitCount) as Item_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as Item_GrossDemandFinalSellingPrice, SKU.Item_fkey, Season_fkey from GrossDemand   inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = GrossDemand.SKU_fkey   group BY SKU.Item_fkey, Media.Season_fkey) as item_gd on item_gd.Item_fkey = s.Item_fkey and item_gd.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as Item_ShippedUnits, sum(ListPrice*UnitCount) as Item_ShippedListPrice, sum(ActivePrice*UnitCount) as Item_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as Item_ShippedFinalSellingPrice,     SKU.Item_fkey, Season_fkey from Shipped       inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Shipped.SKU_fkey       group BY SKU.Item_fkey, Media.Season_fkey) as item_sh on item_sh.Item_fkey = s.Item_fkey and item_sh.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as Item_CancelledUnits, sum(ListPrice*UnitCount) as Item_CancelledListPrice, sum(ActivePrice*UnitCount) as Item_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as Item_CancelledFinalSellingPrice,   SKU.Item_fkey, Season_fkey from Cancellations inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Cancellations.SKU_fkey group BY SKU.Item_fkey, Media.Season_fkey) as item_ca on item_ca.Item_fkey = s.Item_fkey and item_ca.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as Item_ReturnedUnits, sum(ListPrice*UnitCount) as Item_ReturnedListPrice, sum(ActivePrice*UnitCount) as Item_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as Item_ReturnedFinalSellingPrice,    SKU.Item_fkey, Season_fkey from Returns       inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Returns.SKU_fkey       group BY SKU.Item_fkey, Media.Season_fkey) as item_re on item_re.Item_fkey = s.Item_fkey and item_re.Season_fkey = seas.Season_key

	LEFT OUTER JOIN (select sum(UnitCount) as ReferenceItem_GrossDemandUnits, sum(ListPrice*UnitCount) as ReferenceItem_GrossDemandListPrice, sum(ActivePrice*UnitCount) as ReferenceItem_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as ReferenceItem_GrossDemandFinalSellingPrice, Item.ReferenceItem_fkey, Season_fkey from GrossDemand   inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = GrossDemand.SKU_fkey inner join Item on Item.Item_key = SKU.Item_fkey group BY Item.ReferenceItem_fkey, Media.Season_fkey) as ri_gd on ri_gd.ReferenceItem_fkey = i.ReferenceItem_fkey and ri_gd.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as ReferenceItem_ShippedUnits, sum(ListPrice*UnitCount) as ReferenceItem_ShippedListPrice, sum(ActivePrice*UnitCount) as ReferenceItem_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as ReferenceItem_ShippedFinalSellingPrice,     Item.ReferenceItem_fkey, Season_fkey from Shipped       inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Shipped.SKU_fkey inner join Item on Item.Item_key = SKU.Item_fkey group BY Item.ReferenceItem_fkey, Media.Season_fkey) as ri_sh on ri_sh.ReferenceItem_fkey = i.ReferenceItem_fkey and ri_sh.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as ReferenceItem_CancelledUnits, sum(ListPrice*UnitCount) as ReferenceItem_CancelledListPrice, sum(ActivePrice*UnitCount) as ReferenceItem_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as ReferenceItem_CancelledFinalSellingPrice,   Item.ReferenceItem_fkey, Season_fkey from Cancellations inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Cancellations.SKU_fkey inner join Item on Item.Item_key = SKU.Item_fkey group BY Item.ReferenceItem_fkey, Media.Season_fkey) as ri_ca on ri_ca.ReferenceItem_fkey = i.ReferenceItem_fkey and ri_ca.Season_fkey = seas.Season_key
	LEFT OUTER JOIN (select sum(UnitCount) as ReferenceItem_ReturnedUnits, sum(ListPrice*UnitCount) as ReferenceItem_ReturnedListPrice, sum(ActivePrice*UnitCount) as ReferenceItem_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as ReferenceItem_ReturnedFinalSellingPrice,    Item.ReferenceItem_fkey, Season_fkey from Returns       inner join Media on Media_fkey = Media_key inner join SKU on SKU.SKU_key = Returns.SKU_fkey inner join Item on Item.Item_key = SKU.Item_fkey group BY Item.ReferenceItem_fkey, Media.Season_fkey) as ri_re on ri_re.ReferenceItem_fkey = i.ReferenceItem_fkey and ri_re.Season_fkey = seas.Season_key

	where EXISTS (SELECT * from GrossDemand inner join Media on Media_fkey = Media_key where SKU_fkey = s.SKU_key and Season_fkey = seas.Season_key)
		or EXISTS (SELECT * from Shipped inner join Media on Media_fkey = Media_key where SKU_fkey = s.SKU_key and Season_fkey = seas.Season_key)
		or EXISTS (SELECT * from Returns inner join Media on Media_fkey = Media_key where SKU_fkey = s.SKU_key and Season_fkey = seas.Season_key)
		or EXISTS (SELECT * from Cancellations inner join Media on Media_fkey = Media_key where SKU_fkey = s.SKU_key and Season_fkey = seas.Season_key)
	) as a

	--order by a.Season_fkey, a.ReferenceItem_fkey, a.Item_fkey, a.Color_fkey, a.Size_fkey

	TRUNCATE TABLE SKUMediaSalesActivty_DW
	INSERT INTO SKUMediaSalesActivty_DW
	Select
		a.Media_code,
		a.Reference_code,
		a.Item_code,
		a.Color_code,
		a.Size_code,

		CASE
			WHEN a.SKU_ShippedUnits is not NULL and a.SKU_ReturnedUnits is not NULL THEN cast(a.SKU_ReturnedUnits as DECIMAL)/cast(a.SKU_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as SKU_ReturnRate,
		CASE
			WHEN a.ItemColor_ShippedUnits is not NULL and a.ItemColor_ReturnedUnits is not NULL THEN cast(a.ItemColor_ReturnedUnits as DECIMAL)/cast(a.ItemColor_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as ItemColor_ReturnRate,
		CASE
			WHEN a.ItemSize_ShippedUnits is not NULL and a.ItemSize_ReturnedUnits is not NULL THEN cast(a.ItemSize_ReturnedUnits as DECIMAL)/cast(a.ItemSize_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as ItemSize_ReturnRate,
		CASE
			WHEN a.Item_ShippedUnits is not NULL and a.Item_ReturnedUnits is not NULL THEN cast(a.Item_ReturnedUnits as DECIMAL)/cast(a.Item_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as Item_ReturnRate,
		CASE
			WHEN a.ReferenceItem_ShippedUnits is not NULL and a.ReferenceItem_ReturnedUnits is not NULL THEN cast(a.ReferenceItem_ReturnedUnits as DECIMAL)/cast(a.ReferenceItem_ShippedUnits AS DECIMAL)
			ELSE NULL
		END as ReferenceItem_ReturnRate,
		CASE
			WHEN a.SKU_GrossDemandUnits is not NULL and a.SKU_CancelledUnits is not NULL THEN cast(a.SKU_CancelledUnits as DECIMAL)/cast(a.SKU_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_CancellationRate,
		CASE
			WHEN a.ItemColor_GrossDemandUnits is not NULL and a.ItemColor_CancelledUnits is not NULL THEN cast(a.ItemColor_CancelledUnits as DECIMAL)/cast(a.ItemColor_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as ItemColor_CancellationRate,
		CASE
			WHEN a.ItemSize_GrossDemandUnits is not NULL and a.ItemSize_CancelledUnits is not NULL THEN cast(a.ItemSize_CancelledUnits as DECIMAL)/cast(a.ItemSize_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as ItemSize_CancellationRate,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.Item_CancelledUnits is not NULL THEN cast(a.Item_CancelledUnits as DECIMAL)/cast(a.Item_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as Item_CancellationRate,
		CASE
			WHEN a.ReferenceItem_GrossDemandUnits is not NULL and a.ReferenceItem_CancelledUnits is not NULL THEN cast(a.ReferenceItem_CancelledUnits as DECIMAL)/cast(a.ReferenceItem_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as ReferenceItem_CancellationRate,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.ItemSize_GrossDemandUnits is not NULL THEN cast(a.ItemSize_GrossDemandUnits as DECIMAL)/cast(a.Item_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SizePlanPercent,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.ItemColor_GrossDemandUnits is not NULL THEN cast(a.ItemColor_GrossDemandUnits as DECIMAL)/cast(a.Item_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as ColorPlanPercent,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.ReferenceItem_GrossDemandUnits is not NULL THEN cast(a.Item_GrossDemandUnits as DECIMAL)/cast(a.ReferenceItem_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as Item_PercentToReferenceItem,
		CASE
			WHEN a.ItemColor_GrossDemandUnits is not NULL and a.SKU_GrossDemandUnits is not NULL THEN cast(a.SKU_GrossDemandUnits as DECIMAL)/cast(a.ItemColor_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_PercentToItemColor,
		CASE
			WHEN a.ItemSize_GrossDemandUnits is not NULL and a.SKU_GrossDemandUnits is not NULL THEN cast(a.SKU_GrossDemandUnits as DECIMAL)/cast(a.ItemSize_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_PercentToItemSize,
		CASE
			WHEN a.Item_GrossDemandUnits is not NULL and a.SKU_GrossDemandUnits is not NULL THEN cast(a.SKU_GrossDemandUnits as DECIMAL)/cast(a.Item_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_PercentToItem,
		CASE
			WHEN a.ReferenceItem_GrossDemandUnits is not NULL and a.SKU_GrossDemandUnits is not NULL THEN cast(a.SKU_GrossDemandUnits as DECIMAL)/cast(a.ReferenceItem_GrossDemandUnits AS DECIMAL)
			ELSE NULL
		END as SKU_PercentToReferenceItem,

		a.Media_fkey,
		a.ReferenceItem_fkey,
		a.Item_fkey,
		a.Color_fkey,
		a.Size_fkey,
		a.SKU_fkey,

		ISNULL(a.SKU_GrossDemandUnits, 0) as SKU_GrossDemandUnits,
		ISNULL(a.ItemColor_GrossDemandUnits, 0) as ItemColor_GrossDemandUnits,
		ISNULL(a.ItemSize_GrossDemandUnits, 0) as ItemSize_GrossDemandUnits,
		ISNULL(a.Item_GrossDemandUnits, 0) as Item_GrossDemandUnits,
		ISNULL(a.ReferenceItem_GrossDemandUnits, 0) as ReferenceItem_GrossDemandUnits,

		ISNULL(a.SKU_GrossDemandListPrice, 0) as SKU_GrossDemandListPrice,
		ISNULL(a.ItemColor_GrossDemandListPrice, NULL) as ItemColor_GrossDemandListPrice,
		ISNULL(a.ItemSize_GrossDemandListPrice, NULL) as ItemSize_GrossDemandListPrice,
		ISNULL(a.Item_GrossDemandListPrice, 0) as Item_GrossDemandListPrice,
		ISNULL(a.ReferenceItem_GrossDemandListPrice, 0) as ReferenceItem_GrossDemandListPrice,

		ISNULL(a.SKU_GrossDemandActivePrice, 0) as SKU_GrossDemandActivePrice,
		ISNULL(a.ItemColor_GrossDemandActivePrice, NULL) as ItemColor_GrossDemandActivePrice,
		ISNULL(a.ItemSize_GrossDemandActivePrice, NULL) as ItemSize_GrossDemandActivePrice,
		ISNULL(a.Item_GrossDemandActivePrice, 0) as Item_GrossDemandActivePrice,
		ISNULL(a.ReferenceItem_GrossDemandActivePrice, 0) as ReferenceItem_GrossDemandActivePrice,

		ISNULL(a.SKU_GrossDemandFinalSellingPrice, 0) as SKU_GrossDemandFinalSellingPrice,
		ISNULL(a.ItemColor_GrossDemandFinalSellingPrice, NULL) as ItemColor_GrossDemandFinalSellingPrice,
		ISNULL(a.ItemSize_GrossDemandFinalSellingPrice, NULL) as ItemSize_GrossDemandFinalSellingPrice,
		ISNULL(a.Item_GrossDemandFinalSellingPrice, 0) as Item_GrossDemandFinalSellingPrice,
		ISNULL(a.ReferenceItem_GrossDemandFinalSellingPrice, 0) as ReferenceItem_GrossDemandFinalSellingPrice,

		ISNULL(a.SKU_ShippedUnits, 0) as SKU_ShippedUnits,
		ISNULL(a.ItemColor_ShippedUnits, NULL) as ItemColor_ShippedUnits,
		ISNULL(a.ItemSize_ShippedUnits, NULL) as ItemSize_ShippedUnits,
		ISNULL(a.Item_ShippedUnits, 0) as Item_ShippedUnits,
		ISNULL(a.ReferenceItem_ShippedUnits, 0) as ReferenceItem_ShippedUnits,

		ISNULL(a.SKU_ShippedListPrice, 0) as SKU_ShippedListPrice,
		ISNULL(a.ItemColor_ShippedListPrice, NULL) as ItemColor_ShippedListPrice,
		ISNULL(a.ItemSize_ShippedListPrice, NULL) as ItemSize_ShippedListPrice,
		ISNULL(a.Item_ShippedListPrice, 0) as Item_ShippedListPrice,
		ISNULL(a.ReferenceItem_ShippedListPrice, 0) as ReferenceItem_ShippedListPrice, 

		ISNULL(a.SKU_ShippedActivePrice, 0) as SKU_ShippedActivePrice,
		ISNULL(a.ItemColor_ShippedActivePrice, NULL) as ItemColor_ShippedActivePrice,
		ISNULL(a.ItemSize_ShippedActivePrice, NULL) as ItemSize_ShippedActivePrice,
		ISNULL(a.Item_ShippedActivePrice, 0) as Item_ShippedActivePrice,
		ISNULL(a.ReferenceItem_ShippedActivePrice, 0) as ReferenceItem_ShippedActivePrice,

		ISNULL(a.SKU_ShippedFinalSellingPrice, 0) as SKU_ShippedFinalSellingPrice,
		ISNULL(a.ItemColor_ShippedFinalSellingPrice, NULL) as ItemColor_ShippedFinalSellingPrice,
		ISNULL(a.ItemSize_ShippedFinalSellingPrice, NULL) as ItemSize_ShippedFinalSellingPrice,
		ISNULL(a.Item_ShippedFinalSellingPrice, 0) as Item_ShippedFinalSellingPrice,
		ISNULL(a.ReferenceItem_ShippedFinalSellingPrice, 0) as ReferenceItem_ShippedFinalSellingPrice,

		ISNULL(a.SKU_ReturnedUnits, 0) as SKU_ReturnedUnits,
		ISNULL(a.ItemColor_ReturnedUnits, NULL) as ItemColor_ReturnedUnits,
		ISNULL(a.ItemSize_ReturnedUnits, NULL) as ItemSize_ReturnedUnits,
		ISNULL(a.Item_ReturnedUnits, 0) as Item_ReturnedUnits,
		ISNULL(a.ReferenceItem_ReturnedUnits, 0) as ReferenceItem_ReturnedUnits,

		ISNULL(a.SKU_ReturnedListPrice, 0) as SKU_ReturnedListPrice,
		ISNULL(a.ItemColor_ReturnedListPrice, NULL) as ItemColor_ReturnedListPrice,
		ISNULL(a.ItemSize_ReturnedListPrice, NULL) as ItemSize_ReturnedListPrice,
		ISNULL(a.Item_ReturnedListPrice, 0) as Item_ReturnedListPrice,
		ISNULL(a.ReferenceItem_ReturnedListPrice, 0) as ReferenceItem_ReturnedListPrice,

		ISNULL(a.SKU_ReturnedActivePrice, 0) as SKU_ReturnedActivePrice,
		ISNULL(a.ItemColor_ReturnedActivePrice, NULL) as ItemColor_ReturnedActivePrice,
		ISNULL(a.ItemSize_ReturnedActivePrice, NULL) as ItemSize_ReturnedActivePrice,
		ISNULL(a.Item_ReturnedActivePrice, 0) as Item_ReturnedActivePrice,
		ISNULL(a.ReferenceItem_ReturnedActivePrice, 0) as ReferenceItem_ReturnedActivePrice,

		ISNULL(a.SKU_ReturnedFinalSellingPrice, 0) as SKU_ReturnedFinalSellingPrice,
		ISNULL(a.ItemColor_ReturnedFinalSellingPrice, NULL) as ItemColor_ReturnedFinalSellingPrice,
		ISNULL(a.ItemSize_ReturnedFinalSellingPrice, NULL) as ItemSize_ReturnedFinalSellingPrice,
		ISNULL(a.Item_ReturnedFinalSellingPrice, 0) as Item_ReturnedFinalSellingPrice,
		ISNULL(a.ReferenceItem_ReturnedFinalSellingPrice, 0) as ReferenceItem_ReturnedFinalSellingPrice,

		ISNULL(a.SKU_CancelledUnits, 0) as SKU_CancelledUnits,
		ISNULL(a.ItemColor_CancelledUnits, NULL) as ItemColor_CancelledUnits,
		ISNULL(a.ItemSize_CancelledUnits, NULL) as ItemSize_CancelledUnits,
		ISNULL(a.Item_CancelledUnits, 0) as Item_CancelledUnits,
		ISNULL(a.ReferenceItem_CancelledUnits, 0) as ReferenceItem_CancelledUnits,

		ISNULL(a.SKU_CancelledListPrice, 0) as SKU_CancelledListPrice,
		ISNULL(a.ItemColor_CancelledListPrice, NULL) as ItemColor_CancelledListPrice,
		ISNULL(a.ItemSize_CancelledListPrice, NULL) as ItemSize_CancelledListPrice,
		ISNULL(a.Item_CancelledListPrice, 0) as Item_CancelledListPrice,
		ISNULL(a.ReferenceItem_CancelledListPrice, 0) as ReferenceItem_CancelledListPrice,

		ISNULL(a.SKU_CancelledActivePrice, 0) as SKU_CancelledActivePrice,
		ISNULL(a.ItemColor_CancelledActivePrice, NULL) as ItemColor_CancelledActivePrice,
		ISNULL(a.ItemSize_CancelledActivePrice, NULL) as ItemSize_CancelledActivePrice,
		ISNULL(a.Item_CancelledActivePrice, 0) as Item_CancelledActivePrice,
		ISNULL(a.ReferenceItem_CancelledActivePrice, 0) as ReferenceItem_CancelledActivePrice,

		ISNULL(a.SKU_CancelledFinalSellingPrice, 0) as SKU_CancelledFinalSellingPrice,
		ISNULL(a.ItemColor_CancelledFinalSellingPrice, NULL) as ItemColor_CancelledFinalSellingPrice,
		ISNULL(a.ItemSize_CancelledFinalSellingPrice, NULL) as ItemSize_CancelledFinalSellingPrice,
		ISNULL(a.Item_CancelledFinalSellingPrice, 0) as Item_CancelledFinalSellingPrice,
		ISNULL(a.ReferenceItem_CancelledFinalSellingPrice, 0) as ReferenceItem_CancelledFinalSellingPrice

	from
	(SELECT
		s.SKU_key as SKU_fkey,
		i.ReferenceItem_fkey,
		ri.Reference_code,
		s.Item_fkey,
		i.Item_code,
		s.Color_fkey,
		c.Color_code,
		s.Size_fkey,
		sz.Size_code,
		m.Media_key as Media_fkey,
		m.Media_code,

		sku_gd.SKU_GrossDemandUnits,
		sku_gd.SKU_GrossDemandListPrice,
		sku_gd.SKU_GrossDemandActivePrice,
		sku_gd.SKU_GrossDemandFinalSellingPrice,
		sku_ca.SKU_CancelledUnits,
		sku_ca.SKU_CancelledListPrice,
		sku_ca.SKU_CancelledActivePrice,
		sku_ca.SKU_CancelledFinalSellingPrice,
		sku_re.SKU_ReturnedUnits,
		sku_re.SKU_ReturnedListPrice,
		sku_re.SKU_ReturnedActivePrice,
		sku_re.SKU_ReturnedFinalSellingPrice,
		sku_sh.SKU_ShippedUnits,
		sku_sh.SKU_ShippedListPrice,
		sku_sh.SKU_ShippedActivePrice,
		sku_sh.SKU_ShippedFinalSellingPrice,


		itemColor_gd.ItemColor_GrossDemandUnits,
	/*
		itemColor_gd.ItemColor_GrossDemandListPrice,
		itemColor_gd.ItemColor_GrossDemandActivePrice,
		itemColor_gd.ItemColor_GrossDemandFinalSellingPrice,
		itemColor_ca.ItemColor_CancelledUnits,
		itemColor_ca.ItemColor_CancelledListPrice,
		itemColor_ca.ItemColor_CancelledActivePrice,
		itemColor_ca.ItemColor_CancelledFinalSellingPrice,
		itemColor_re.ItemColor_ReturnedUnits,
		itemColor_re.ItemColor_ReturnedListPrice,
		itemColor_re.ItemColor_ReturnedActivePrice,
		itemColor_re.ItemColor_ReturnedFinalSellingPrice,
		itemColor_sh.ItemColor_ShippedUnits,
		itemColor_sh.ItemColor_ShippedListPrice,
		itemColor_sh.ItemColor_ShippedActivePrice,
		itemColor_sh.ItemColor_ShippedFinalSellingPrice,
	*/
		NULL as ItemColor_GrossDemandListPrice,
		NULL as ItemColor_GrossDemandActivePrice,
		NULL as ItemColor_GrossDemandFinalSellingPrice,
		NULL as ItemColor_CancelledUnits,
		NULL as ItemColor_CancelledListPrice,
		NULL as ItemColor_CancelledActivePrice,
		NULL as ItemColor_CancelledFinalSellingPrice,
		NULL as ItemColor_ReturnedUnits,
		NULL as ItemColor_ReturnedListPrice,
		NULL as ItemColor_ReturnedActivePrice,
		NULL as ItemColor_ReturnedFinalSellingPrice,
		NULL as ItemColor_ShippedUnits,
		NULL as ItemColor_ShippedListPrice,
		NULL as ItemColor_ShippedActivePrice,
		NULL as ItemColor_ShippedFinalSellingPrice,


		itemSize_gd.ItemSize_GrossDemandUnits,
	/*
		itemSize_gd.ItemSize_GrossDemandListPrice,
		itemSize_gd.ItemSize_GrossDemandActivePrice,
		itemSize_gd.ItemSize_GrossDemandFinalSellingPrice,
		itemSize_ca.ItemSize_CancelledUnits,
		itemSize_ca.ItemSize_CancelledListPrice,
		itemSize_ca.ItemSize_CancelledActivePrice,
		itemSize_ca.ItemSize_CancelledFinalSellingPrice,
		itemSize_re.ItemSize_ReturnedUnits,
		itemSize_re.ItemSize_ReturnedListPrice,
		itemSize_re.ItemSize_ReturnedActivePrice,
		itemSize_re.ItemSize_ReturnedFinalSellingPrice,
		itemSize_sh.ItemSize_ShippedUnits,
		itemSize_sh.ItemSize_ShippedListPrice,
		itemSize_sh.ItemSize_ShippedActivePrice,
		itemSize_sh.ItemSize_ShippedFinalSellingPrice,
	*/
		NULL as ItemSize_GrossDemandListPrice,
		NULL as ItemSize_GrossDemandActivePrice,
		NULL as ItemSize_GrossDemandFinalSellingPrice,
		NULL as ItemSize_CancelledUnits,
		NULL as ItemSize_CancelledListPrice,
		NULL as ItemSize_CancelledActivePrice,
		NULL as ItemSize_CancelledFinalSellingPrice,
		NULL as ItemSize_ReturnedUnits,
		NULL as ItemSize_ReturnedListPrice,
		NULL as ItemSize_ReturnedActivePrice,
		NULL as ItemSize_ReturnedFinalSellingPrice,
		NULL as ItemSize_ShippedUnits,
		NULL as ItemSize_ShippedListPrice,
		NULL as ItemSize_ShippedActivePrice,
		NULL as ItemSize_ShippedFinalSellingPrice,

		item_gd.Item_GrossDemandUnits,
		item_gd.Item_GrossDemandListPrice,
		item_gd.Item_GrossDemandActivePrice,
		item_gd.Item_GrossDemandFinalSellingPrice,
		item_ca.Item_CancelledUnits,
		item_ca.Item_CancelledListPrice,
		item_ca.Item_CancelledActivePrice,
		item_ca.Item_CancelledFinalSellingPrice,
		item_re.Item_ReturnedUnits,
		item_re.Item_ReturnedListPrice,
		item_re.Item_ReturnedActivePrice,
		item_re.Item_ReturnedFinalSellingPrice,
		item_sh.Item_ShippedUnits,
		item_sh.Item_ShippedListPrice,
		item_sh.Item_ShippedActivePrice,
		item_sh.Item_ShippedFinalSellingPrice,

		ri_gd.ReferenceItem_GrossDemandUnits,
		ri_gd.ReferenceItem_GrossDemandListPrice,
		ri_gd.ReferenceItem_GrossDemandActivePrice,
		ri_gd.ReferenceItem_GrossDemandFinalSellingPrice,
		ri_ca.ReferenceItem_CancelledUnits,
		ri_ca.ReferenceItem_CancelledListPrice,
		ri_ca.ReferenceItem_CancelledActivePrice,
		ri_ca.ReferenceItem_CancelledFinalSellingPrice,
		ri_re.ReferenceItem_ReturnedUnits,
		ri_re.ReferenceItem_ReturnedListPrice,
		ri_re.ReferenceItem_ReturnedActivePrice,
		ri_re.ReferenceItem_ReturnedFinalSellingPrice,
		ri_sh.ReferenceItem_ShippedUnits,
		ri_sh.ReferenceItem_ShippedListPrice,
		ri_sh.ReferenceItem_ShippedActivePrice,
		ri_sh.ReferenceItem_ShippedFinalSellingPrice


FROM

	(SELECT distinct SKU_fkey, Media_fkey from GrossDemand
 	 UNION
	 SELECT distinct SKU_fkey, Media_fkey from Shipped
	 UNION
	 SELECT distinct SKU_fkey, Media_fkey from Cancellations
	 UNION
	 SELECT distinct SKU_fkey, Media_fkey from Returns) as z

	INNER join SKU s on s.SKU_key = z.SKU_fkey
	inner join Item i on i.Item_key = s.Item_fkey
	inner join Color c on c.Color_key = s.Color_fkey
	inner JOIN Size sz on sz.Size_key = s.Size_fkey
	INNER join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
	inner join Media m on m.Media_key = z.Media_fkey

	LEFT OUTER JOIN (select sum(UnitCount) as SKU_GrossDemandUnits, sum(ListPrice*UnitCount) as SKU_GrossDemandListPrice, sum(ActivePrice*UnitCount) as SKU_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as SKU_GrossDemandFinalSellingPrice, SKU_fkey, Media_fkey from GrossDemand group BY GrossDemand.SKU_fkey,   GrossDemand.Media_fkey) as sku_gd on sku_gd.SKU_fkey = s.SKU_key and sku_gd.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as SKU_ShippedUnits, sum(ListPrice*UnitCount) as SKU_ShippedListPrice, sum(ActivePrice*UnitCount) as SKU_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as SKU_ShippedFinalSellingPrice,     SKU_fkey, Media_fkey from Shipped                 group BY Shipped.SKU_fkey,       Shipped.Media_fkey) as sku_sh on sku_sh.SKU_fkey = s.SKU_key and sku_sh.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as SKU_CancelledUnits, sum(ListPrice*UnitCount) as SKU_CancelledListPrice, sum(ActivePrice*UnitCount) as SKU_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as SKU_CancelledFinalSellingPrice,   SKU_fkey, Media_fkey from Cancellations group BY Cancellations.SKU_fkey, Cancellations.Media_fkey) as sku_ca on sku_ca.SKU_fkey = s.SKU_key and sku_ca.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as SKU_ReturnedUnits, sum(ListPrice*UnitCount) as SKU_ReturnedListPrice, sum(ActivePrice*UnitCount) as SKU_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as SKU_ReturnedFinalSellingPrice,      SKU_fkey, Media_fkey from Returns       group BY Returns.SKU_fkey,       Returns.Media_fkey) as sku_re on sku_re.SKU_fkey = s.SKU_key and sku_re.Media_fkey = m.Media_key


	LEFT OUTER JOIN (select sum(UnitCount) as ItemColor_GrossDemandUnits, sum(ListPrice*UnitCount) as ItemColor_GrossDemandListPrice, sum(ActivePrice*UnitCount) as ItemColor_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as ItemColor_GrossDemandFinalSellingPrice, SKU.Item_fkey, SKU.Color_fkey, Media_fkey from GrossDemand inner join SKU on SKU.SKU_key = GrossDemand.SKU_fkey   group BY SKU.Item_fkey, SKU.Color_fkey, GrossDemand.Media_fkey) as itemColor_gd on itemColor_gd.Item_fkey = s.Item_fkey AND itemColor_gd.Color_fkey = s.Color_fkey and itemColor_gd.Media_fkey = m.Media_key
	/*
	LEFT OUTER JOIN (select sum(UnitCount) as ItemColor_ShippedUnits, sum(ListPrice*UnitCount) as ItemColor_ShippedListPrice, sum(ActivePrice*UnitCount) as ItemColor_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as ItemColor_ShippedFinalSellingPrice,     SKU.Item_fkey, SKU.Color_fkey, Media_fkey from Shipped       inner join SKU on SKU.SKU_key = Shipped.SKU_fkey       group BY SKU.Item_fkey, SKU.Color_fkey, Shipped.Media_fkey) as itemColor_sh on itemColor_sh.Item_fkey = s.Item_fkey AND itemColor_sh.Color_fkey = s.Color_fkey and itemColor_sh.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as ItemColor_CancelledUnits, sum(ListPrice*UnitCount) as ItemColor_CancelledListPrice, sum(ActivePrice*UnitCount) as ItemColor_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as ItemColor_CancelledFinalSellingPrice,   SKU.Item_fkey, SKU.Color_fkey, Media_fkey from Cancellations inner join SKU on SKU.SKU_key = Cancellations.SKU_fkey group BY SKU.Item_fkey, SKU.Color_fkey, Cancellations.Media_fkey) as itemColor_ca on itemColor_ca.Item_fkey = s.Item_fkey AND itemColor_ca.Color_fkey = s.Color_fkey and itemColor_ca.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as ItemColor_ReturnedUnits, sum(ListPrice*UnitCount) as ItemColor_ReturnedListPrice, sum(ActivePrice*UnitCount) as ItemColor_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as ItemColor_ReturnedFinalSellingPrice,    SKU.Item_fkey, SKU.Color_fkey, Media_fkey from Returns       inner join SKU on SKU.SKU_key = Returns.SKU_fkey       group BY SKU.Item_fkey, SKU.Color_fkey, Returns.Media_fkey) as itemColor_re on itemColor_re.Item_fkey = s.Item_fkey AND itemColor_re.Color_fkey = s.Color_fkey and itemColor_re.Media_fkey = m.Media_key
	*/

	LEFT OUTER JOIN (select sum(UnitCount) as ItemSize_GrossDemandUnits, sum(ListPrice*UnitCount) as ItemSize_GrossDemandListPrice, sum(ActivePrice*UnitCount) as ItemSize_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as ItemSize_GrossDemandFinalSellingPrice, SKU.Item_fkey, SKU.Size_fkey, Media_fkey from GrossDemand   inner join SKU on SKU.SKU_key = GrossDemand.SKU_fkey group BY SKU.Item_fkey, SKU.Size_fkey, GrossDemand.Media_fkey) as ItemSize_gd on ItemSize_gd.Item_fkey = s.Item_fkey AND ItemSize_gd.Size_fkey = s.Size_fkey and ItemSize_gd.Media_fkey = m.Media_key
	/*
	LEFT OUTER JOIN (select sum(UnitCount) as ItemSize_ShippedUnits, sum(ListPrice*UnitCount) as ItemSize_ShippedListPrice, sum(ActivePrice*UnitCount) as ItemSize_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as ItemSize_ShippedFinalSellingPrice,     SKU.Item_fkey, SKU.Size_fkey, Media_fkey from Shipped       inner join SKU on SKU.SKU_key = Shipped.SKU_fkey group BY SKU.Item_fkey, SKU.Size_fkey, Shipped.Media_fkey) as ItemSize_sh on ItemSize_sh.Item_fkey = s.Item_fkey AND ItemSize_sh.Size_fkey = s.Size_fkey and ItemSize_sh.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as ItemSize_CancelledUnits, sum(ListPrice*UnitCount) as ItemSize_CancelledListPrice, sum(ActivePrice*UnitCount) as ItemSize_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as ItemSize_CancelledFinalSellingPrice,   SKU.Item_fkey, SKU.Size_fkey, Media_fkey from Cancellations inner join SKU on SKU.SKU_key = Cancellations.SKU_fkey group BY SKU.Item_fkey, SKU.Size_fkey, Cancellations.Media_fkey) as ItemSize_ca on ItemSize_ca.Item_fkey = s.Item_fkey AND ItemSize_ca.Size_fkey = s.Size_fkey and ItemSize_ca.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as ItemSize_ReturnedUnits, sum(ListPrice*UnitCount) as ItemSize_ReturnedListPrice, sum(ActivePrice*UnitCount) as ItemSize_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as ItemSize_ReturnedFinalSellingPrice,    SKU.Item_fkey, SKU.Size_fkey, Media_fkey from Returns       inner join SKU on SKU.SKU_key = Returns.SKU_fkey group BY SKU.Item_fkey, SKU.Size_fkey, Returns.Media_fkey) as ItemSize_re on ItemSize_re.Item_fkey = s.Item_fkey AND ItemSize_re.Size_fkey = s.Size_fkey and ItemSize_re.Media_fkey = m.Media_key
	*/

	LEFT OUTER JOIN (select sum(UnitCount) as Item_GrossDemandUnits, sum(ListPrice*UnitCount) as Item_GrossDemandListPrice, sum(ActivePrice*UnitCount) as Item_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as Item_GrossDemandFinalSellingPrice, SKU.Item_fkey, Media_fkey from GrossDemand   inner join SKU on SKU.SKU_key = GrossDemand.SKU_fkey   group BY SKU.Item_fkey, GrossDemand.Media_fkey) as item_gd on item_gd.Item_fkey = s.Item_fkey and item_gd.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as Item_ShippedUnits, sum(ListPrice*UnitCount) as Item_ShippedListPrice, sum(ActivePrice*UnitCount) as Item_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as Item_ShippedFinalSellingPrice,     SKU.Item_fkey, Media_fkey from Shipped       inner join SKU on SKU.SKU_key = Shipped.SKU_fkey       group BY SKU.Item_fkey, Shipped.Media_fkey) as item_sh on item_sh.Item_fkey = s.Item_fkey and item_sh.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as Item_CancelledUnits, sum(ListPrice*UnitCount) as Item_CancelledListPrice, sum(ActivePrice*UnitCount) as Item_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as Item_CancelledFinalSellingPrice,   SKU.Item_fkey, Media_fkey from Cancellations inner join SKU on SKU.SKU_key = Cancellations.SKU_fkey group BY SKU.Item_fkey, Cancellations.Media_fkey) as item_ca on item_ca.Item_fkey = s.Item_fkey and item_ca.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as Item_ReturnedUnits, sum(ListPrice*UnitCount) as Item_ReturnedListPrice, sum(ActivePrice*UnitCount) as Item_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as Item_ReturnedFinalSellingPrice,    SKU.Item_fkey, Media_fkey from Returns       inner join SKU on SKU.SKU_key = Returns.SKU_fkey       group BY SKU.Item_fkey, Returns.Media_fkey) as item_re on item_re.Item_fkey = s.Item_fkey and item_re.Media_fkey = m.Media_key

	LEFT OUTER JOIN (select sum(UnitCount) as ReferenceItem_GrossDemandUnits, sum(ListPrice*UnitCount) as ReferenceItem_GrossDemandListPrice, sum(ActivePrice*UnitCount) as ReferenceItem_GrossDemandActivePrice, sum(FinalSellingPrice*UnitCount) as ReferenceItem_GrossDemandFinalSellingPrice, Item.ReferenceItem_fkey, Media_fkey from GrossDemand   inner join SKU on SKU.SKU_key = GrossDemand.SKU_fkey inner join Item on Item.Item_key = SKU.Item_fkey group BY Item.ReferenceItem_fkey, GrossDemand.Media_fkey) as ri_gd on ri_gd.ReferenceItem_fkey = i.ReferenceItem_fkey and ri_gd.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as ReferenceItem_ShippedUnits, sum(ListPrice*UnitCount) as ReferenceItem_ShippedListPrice, sum(ActivePrice*UnitCount) as ReferenceItem_ShippedActivePrice, sum(FinalSellingPrice*UnitCount) as ReferenceItem_ShippedFinalSellingPrice,     Item.ReferenceItem_fkey, Media_fkey from Shipped       inner join SKU on SKU.SKU_key = Shipped.SKU_fkey inner join Item on Item.Item_key = SKU.Item_fkey group BY Item.ReferenceItem_fkey, Shipped.Media_fkey) as ri_sh on ri_sh.ReferenceItem_fkey = i.ReferenceItem_fkey and ri_sh.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as ReferenceItem_CancelledUnits, sum(ListPrice*UnitCount) as ReferenceItem_CancelledListPrice, sum(ActivePrice*UnitCount) as ReferenceItem_CancelledActivePrice, sum(FinalSellingPrice*UnitCount) as ReferenceItem_CancelledFinalSellingPrice,   Item.ReferenceItem_fkey, Media_fkey from Cancellations inner join SKU on SKU.SKU_key = Cancellations.SKU_fkey inner join Item on Item.Item_key = SKU.Item_fkey group BY Item.ReferenceItem_fkey, Cancellations.Media_fkey) as ri_ca on ri_ca.ReferenceItem_fkey = i.ReferenceItem_fkey and ri_ca.Media_fkey = m.Media_key
	LEFT OUTER JOIN (select sum(UnitCount) as ReferenceItem_ReturnedUnits, sum(ListPrice*UnitCount) as ReferenceItem_ReturnedListPrice, sum(ActivePrice*UnitCount) as ReferenceItem_ReturnedActivePrice, sum(FinalSellingPrice*UnitCount) as ReferenceItem_ReturnedFinalSellingPrice,    Item.ReferenceItem_fkey, Media_fkey from Returns       inner join SKU on SKU.SKU_key = Returns.SKU_fkey inner join Item on Item.Item_key = SKU.Item_fkey group BY Item.ReferenceItem_fkey, Returns.Media_fkey) as ri_re on ri_re.ReferenceItem_fkey = i.ReferenceItem_fkey and ri_re.Media_fkey = m.Media_key
	) as a

	--order by a.Season_fkey, a.ReferenceItem_fkey, a.Item_fkey, a.Color_fkey, a.Size_fkey

	return 0	
END TRY
BEGIN CATCH
	return 1
END CATCH
END
GO
