-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[usfIsAFullPriceAppearanceInSecondHalfOfSeasonBy_SeasonKey_SKUKey] 
(
	@SeasonKey int,
	@SKUKey int
)
RETURNS int
AS
BEGIN
	DECLARE @TrueOrFalse int

	IF 	(exists (SELECT 
		* 
		from Media_SKU ms
		inner join Media m on m.Media_key = ms.Media_fkey 
		inner join MediaType mt on mt.MediaType_key = m.MediaType_fkey
		inner join SKU s ON s.SKU_key = ms.SKU_fkey
		inner join Item i on i.Item_key = s.Item_fkey
		inner join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
		where ms.Deleted = 0 
		and m.Season_fkey = @SeasonKey 
		and ms.SKU_fkey = @SKUKey 					
		and ri.Division_fkey = m.Division_fkey 
		and mt.Name <> 'Clearance'
		and datediff(day, (select TOP 1 Season.StartDate from Season where Season.Season_key = @SeasonKey), m.ActivatedDate) 
				>= datediff(day, (SELECT TOP 1 Season.StartDate from Season where Season.Season_key = @SeasonKey), (SELECT TOP 1 Season.StartDate from Season where Season.Season_key = dbo.usfGetNextSeasonKeyBy_SeasonKey(@SeasonKey)))/2)

		and not exists (SELECT 
		* 
		from Media_SKU ms
		inner join Media m on m.Media_key = ms.Media_fkey 
		inner join MediaType mt on mt.MediaType_key = m.MediaType_fkey
		inner join SKU s ON s.SKU_key = ms.SKU_fkey
		inner join Item i on i.Item_key = s.Item_fkey
		inner join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
		where ms.Deleted = 0 
		and m.Season_fkey = @SeasonKey 
		and ms.SKU_fkey = @SKUKey 					
		and ri.Division_fkey = m.Division_fkey 
		and mt.Name <> 'Clearance'
		and datediff(day, (select TOP 1 Season.StartDate from Season where Season.Season_key = @SeasonKey), m.ActivatedDate) 
				< datediff(day, (SELECT TOP 1 Season.StartDate from Season where Season.Season_key = @SeasonKey), (SELECT TOP 1 Season.StartDate from Season where Season.Season_key = dbo.usfGetNextSeasonKeyBy_SeasonKey(@SeasonKey)))/2))
 
		SET @TrueOrFalse = 1
	ELSE
		SET @TrueOrFalse = 0


	RETURN @TrueOrFalse
END
GO
