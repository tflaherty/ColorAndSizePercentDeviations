-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION usfGetLastFullPriceAppearanceCountInFirstHalfOfSeasonBy_SKUKey_SeasonKey
(
	@SKUKey int,
	@SeasonKey int
)
	returns int
AS
BEGIN
	DECLARE @TheCount int

	select @TheCount = count(*) 
		FROM Media_SKU ms 
		inner join Media m on m.Media_key = ms.Media_fkey 
		inner join SKU s on s.SKU_key = ms.SKU_fkey
		inner join Item i on i.Item_key = s.Item_fkey
		inner join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
		WHERE 
			ms.SKU_fkey = @SKUKey 
			and m.Season_fkey = @SeasonKey 
			and ms.Deleted = 0
			and m.Division_fkey = ri.Division_fkey
			and datediff(day, (select TOP 1 Season.StartDate from Season where Season.Season_key = @SeasonKey), m.ActivatedDate) 
				< datediff(day, (SELECT TOP 1 Season.StartDate from Season where Season.Season_key = @SeasonKey), (SELECT TOP 1 Season.StartDate from Season where Season.Season_key = dbo.usfGetNextSeasonKeyBy_SeasonKey(@SeasonKey)))/2
	
	RETURN @TheCount

END
GO
