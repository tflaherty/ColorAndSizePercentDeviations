CREATE VIEW [dbo].[VW_SelectTTASizePlanEntriesThatNeedChanging]
AS
select 
	SizePlanEntry_key,
	SizePlanEntry.Size_fkey as OldSizeKey,
	(select top 1 AllTTASizePlanEntriesThatNeedChanging.NewSizeKey from AllTTASizePlanEntriesThatNeedChanging where AllTTASizePlanEntriesThatNeedChanging.SizePlanEntry_key = SizePlanEntry.SizePlanEntry_key) as NewSizeKey
from SizePlanEntry 
where EXISTS (select * from AllTTASizePlanEntriesThatNeedChanging where AllTTASizePlanEntriesThatNeedChanging.SizePlanEntry_key = SizePlanEntry.SizePlanEntry_key AND AllTTASizePlanEntriesThatNeedChanging.NewSizeKey IN (269, 270, 271, 272, 273))
and (select count(*) from AllTTASizePlanEntriesThatNeedChanging where AllTTASizePlanEntriesThatNeedChanging.SizePlanEntry_key = SizePlanEntry.SizePlanEntry_key) = 1


GO
