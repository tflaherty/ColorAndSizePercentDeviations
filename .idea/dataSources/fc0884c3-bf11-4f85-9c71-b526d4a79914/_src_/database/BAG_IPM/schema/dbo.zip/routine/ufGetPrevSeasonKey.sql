-- =============================================
-- Author:		Thomas Flaherty
-- Create date: Nov. 2, 2010
-- Description:	Get the key for the previous Season
-- =============================================
CREATE FUNCTION [dbo].[ufGetPrevSeasonKey]
(
)
RETURNS int
AS
BEGIN
	declare @PreviousSeasonKey int

	SELECT    Top 1 @PreviousSeasonKey = s2.Season_key 
	FROM         Season AS s1 INNER JOIN
						  Season AS s2 ON s1.StartDate > s2.StartDate 
	WHERE     (s1.Season_key = dbo.ufGetCurrentSeasonKey())
	ORDER BY s2.StartDate DESC

	RETURN @PreviousSeasonKey

END
GO
