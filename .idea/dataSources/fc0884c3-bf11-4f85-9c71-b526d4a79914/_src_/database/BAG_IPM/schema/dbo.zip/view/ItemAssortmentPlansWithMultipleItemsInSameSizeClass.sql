/*order by seas.StartDate desc, i.ReferenceItem_fkey, i.SizeClass_fkey*/
CREATE VIEW [dbo].[ItemAssortmentPlansWithMultipleItemsInSameSizeClass]
AS
SELECT seas.Season_code, m.Media_code, ri.Reference_code, i.Item_code, sc.Name AS SizeClassName, m.InHomeDate AS InHomeDate, 
                   (SELECT COUNT(*) AS Expr1
                    FROM   dbo.ItemAssortmentPlan AS iap2 INNER JOIN
                                   dbo.ItemAssortmentPlanSizeClassData AS iapscd2 ON iapscd2.ItemAssortmentPlan_fkey = iap2.ItemAssortmentPlan_key INNER JOIN
                                   dbo.Item AS i2 ON i2.Item_key = iapscd2.Item_fkey
                    WHERE (iap2.Media_fkey = m.Media_key) AND (i2.ReferenceItem_fkey = i.ReferenceItem_fkey) AND (i2.SizeClass_fkey = i.SizeClass_fkey)) AS NumIAPSCDs,
                   (SELECT COUNT(*) AS Expr1
                    FROM   dbo.ItemAssortmentPlan AS iap2
                    WHERE (Media_fkey = m.Media_key) AND (ReferenceItem_fkey = iap.ReferenceItem_fkey)) AS NumIAPs, 
					m.Media_key, 
					ri.ReferenceItem_key, i.Item_key, i.SizeClass_fkey,
					seas.StartDate AS SeasonStartDate
FROM  dbo.ItemAssortmentPlan AS iap INNER JOIN
               dbo.ItemAssortmentPlanSizeClassData AS iapscd ON iapscd.ItemAssortmentPlan_fkey = iap.ItemAssortmentPlan_key INNER JOIN
               dbo.Item AS i ON i.Item_key = iapscd.Item_fkey INNER JOIN
               dbo.SizeClass AS sc ON sc.SizeClass_key = i.SizeClass_fkey INNER JOIN
               dbo.Media AS m ON m.Media_key = iap.Media_fkey INNER JOIN
               dbo.Season AS seas ON seas.Season_key = m.Season_fkey INNER JOIN
               dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = iap.ReferenceItem_fkey
WHERE EXISTS
                   (SELECT iapscd2.ItemAssortmentPlanSizeClassData_key, iapscd2.ItemAssortmentPlan_fkey, iapscd2.PercentToReferenceItem, iapscd2.Item_fkey, 
                                   iapscd2.AvgSellingPrice, iapscd2.AvgListPrice, iapscd2.DemandCurve_fkey, iapscd2.Deleted, iapscd2.ReturnRate, 
                                   iapscd2.GrossDemandUnitsUsingListPrice, iap2.ItemAssortmentPlan_key, iap2.Media_fkey, iap2.ReferenceItem_fkey, iap2.ColorPlan_fkey, 
                                   iap2.SizePlan_fkey, iap2.PlanType_fkey, iap2.PercentToAverageGross, iap2.TrendPercentage, iap2.TrendMedia_fkey, iap2.PlanningMode_fkey, 
                                   iap2.ModelColorDescriptions, iap2.ReturnRate AS Expr1, iap2.Page, iap2.TotalSpace, iap2.ModelColor_fkey, iap2.UseActualReturnRate, 
                                   iap2.UseActualColorPercentages, iap2.UseActualSizePercentages, iap2.Locked, iap2.Deleted AS Expr2, iap2.Comment, iap2.SavedDate, iap2.PlanGross, 
                                   iap2.PercentToBook, iap2.GrossDemandUnitsUsingListPrice AS Expr3, iap2.GrossDemandCentsPerCirc, iap2.UseActualPercentToReferenceItems, 
                                   i2.Item_key, i2.Item_code, i2.ReferenceItem_fkey AS Expr4, i2.SizeClass_fkey
                    FROM   dbo.ItemAssortmentPlanSizeClassData AS iapscd2 INNER JOIN
                                   dbo.ItemAssortmentPlan AS iap2 ON iap2.ItemAssortmentPlan_key = iapscd2.ItemAssortmentPlan_fkey INNER JOIN
                                   dbo.Item AS i2 ON i2.Item_key = iapscd2.Item_fkey
                    WHERE (i2.Item_key <> i.Item_key) AND (i2.ReferenceItem_fkey = i.ReferenceItem_fkey) AND (i2.SizeClass_fkey = i.SizeClass_fkey) AND 
                                   (iap2.Media_fkey = iap.Media_fkey))
GO
