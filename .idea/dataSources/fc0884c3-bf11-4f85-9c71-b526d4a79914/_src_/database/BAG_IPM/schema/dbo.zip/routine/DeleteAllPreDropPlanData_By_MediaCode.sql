-- =============================================
-- Author:		Thomas Flaherty
-- Create date: 2/16/15
-- Description:	Deletes all data for pre drop plans
-- (item assortment plan, item assortment plan size class data,
-- color plan, size plan)
-- =============================================
CREATE PROCEDURE [dbo].[DeleteAllPreDropPlanData_By_MediaCode]
	@MediaCode varchar(128) = 0, 
	@NumRowsDeleted int = 0 OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- make a temporary table that holds all the keys we need
	-- for the deletions
	if object_id('tempdb..#TmpPreDropPlanDeletionData') is not null
	begin
	  DROP TABLE #TmpPreDropPlanDeletionData
	end
	SELECT 
		iap.ItemAssortmentPlan_key, iap.ColorPlan_fkey, iap.SizePlan_fkey
	into #TmpPreDropPlanDeletionData
	from ItemAssortmentPlan iap
	inner join Media m on m.Media_key = iap.Media_fkey
	INNER join PlanType pt on pt.PlanType_key = iap.PlanType_fkey
	where m.Media_code = @MediaCode and pt.Name = 'PreDrop'

	DELETE iapscd FROM ItemAssortmentPlanSizeClassData iapscd
	where iapscd.ItemAssortmentPlan_fkey in (SELECT DISTINCT ItemAssortmentPlan_key FROM #TmpPreDropPlanDeletionData)
	select @NumRowsDeleted = @@ROWCOUNT

	DELETE iap FROM ItemAssortmentPlan iap
	where iap.ItemAssortmentPlan_key in (SELECT DISTINCT ItemAssortmentPlan_key FROM #TmpPreDropPlanDeletionData)
	select @NumRowsDeleted = @NumRowsDeleted + @@ROWCOUNT

	DELETE cpe FROM ColorPlanEntry cpe
	where cpe.ColorPlan_fkey in (SELECT DISTINCT ColorPlan_fkey FROM #TmpPreDropPlanDeletionData)
	select @NumRowsDeleted = @NumRowsDeleted + @@ROWCOUNT

	DELETE cp FROM ColorPlan cp
	where cp.ColorPlan_key in (SELECT DISTINCT ColorPlan_fkey FROM #TmpPreDropPlanDeletionData)
	select @NumRowsDeleted = @NumRowsDeleted + @@ROWCOUNT

	DELETE spe FROM SizePlanEntry spe
	where spe.SizePlan_fkey in (SELECT DISTINCT SizePlan_fkey FROM #TmpPreDropPlanDeletionData)
	select @NumRowsDeleted = @NumRowsDeleted + @@ROWCOUNT

	DELETE sp FROM SizePlan sp
	where sp.SizePlan_key in (SELECT DISTINCT SizePlan_fkey FROM #TmpPreDropPlanDeletionData)
	select @NumRowsDeleted = @NumRowsDeleted + @@ROWCOUNT

	if object_id('tempdb..#TmpPreDropPlanDeletionData') is not null
	begin
	  DROP TABLE #TmpPreDropPlanDeletionData
	end

END
GO
