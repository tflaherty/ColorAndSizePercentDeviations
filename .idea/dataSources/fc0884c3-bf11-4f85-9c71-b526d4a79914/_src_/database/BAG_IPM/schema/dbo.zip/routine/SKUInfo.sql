-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION SKUInfo
(	
	-- Add the parameters for the function here
	@SKUKey int
)
RETURNS TABLE 
AS
RETURN 
(
SELECT 
	s.SKU_key,
	s.SKUDispositionStatusType_fkey,
	s.SKUBackOrderDispositionStatusType_fkey,
	i.Item_key,
	i.Item_code,
	ri.ReferenceItem_key,
	ri.Reference_code,
	ri.Vendor_fkey,
	ri.Class_fkey,
	ri.Description as ReferenceItemDescription,
	ri.Name as ReferenceItemName,
	ri.Common,
	dep.Department_key,
	dep.Department_code,
	dep.Segment_fkey,
	dep.Name as DepartmentName,
	dep.Description as DepartmentDescription,
	dep.EcometryDepartment_code,
	div.Division_key,
	div.Division_code,
	div.Name as DivisionName,
	div.Description as DivisionDescription,
	c.Color_key,
	c.Color_code,
	c.Description as ColorDescription,
	c.IsShoeColor,
	sz.Size_key,
	sz.Size_code,
	sz.IsShoeSize,
	sc.SizeClass_key,
	sc.SizeClass_code,
	sc.Name as SizeClassName,
	sc.Description as SizeClassDescription,
	sc.EcometrySizeClass_code
FROM
	SKU s
	INNER JOIN Item i
		ON i.Item_key = s.Item_fkey
	INNER JOIN ReferenceItem ri
		ON ri.ReferenceItem_key = i.ReferenceItem_fkey
	INNER JOIN Department dep
		ON dep.Department_key = ri.Department_fkey
	INNER JOIN Division div 
		ON div.Division_key = ri.Division_fkey
	INNER JOIN Color c
		ON c.Color_key = s.Color_fkey
	INNER JOIN [Size] sz
		ON sz.Size_key = s.Size_fkey
	INNER JOIN SizeClass sc
		ON sc.SizeClass_key = i.SizeClass_fkey

	WHERE s.SKU_key = @SKUKey
)

GO
