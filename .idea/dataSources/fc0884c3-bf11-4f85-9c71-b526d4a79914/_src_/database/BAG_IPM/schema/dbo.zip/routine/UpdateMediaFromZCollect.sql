-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateMediaFromZCollect]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	Insert into Media
      (Media_code,MediaFormat_fkey,MediaType_fkey,Name,Description,MediaStatus_fkey,
        season_fkey,OrderWithinSeason,Division_fkey,InHomeDate,ActivatedDate,InactivatedDate,
        Promo_fkey,Circulation,Priority,CurveStartDate,
        OldMedia_code,
        Quarter,
        InHomeDate2,
        LastYearsMedia_fkey,
        ParentMedia_fkey,
        ParentMediaRelationshipType_fkey,
        DefaultDemandCurve_fkey)
Select
--    NULL as Media_key,
     c.Media_Code as Media_code,
     CASE
         WHEN substring(c.Media_Code, 4, 1) in ('A','B','E','F') THEN 
(select mf.MediaFormat_key from MediaFormat mf where mf.Name = 'Print')
         ELSE (select mf.MediaFormat_key from MediaFormat mf where 
mf.Name = 'Web')
     END MediaFormat_fkey,
     CASE
         WHEN substring(c.Media_Code, 4, 1) in ('A','C','E','G') THEN 
(select mt.MediaType_key from MediaType mt where mt.Name = 'Regular')
         ELSE (select mt.MediaType_key from MediaType mt where mt.Name = 
'Clearance')
     END MediaType_fkey,
     c.Name,
     NULL as [Description],
     (select ms.MediaStatus_key from MediaStatus ms where ms.Name = 
'Planning') as MediaStatus_fkey,
     (select seas.Season_key from Season seas WHERE seas.Season_code = 
c.Season_code) as Season_fkey,
     NULL as OrderWithinSeason,
     CASE
         WHEN substring(c.Media_Code, 4, 1) in ('A','B','C','D') THEN 
(select div.Division_key from Division div where div.Name = 'Chadwicks')
         ELSE (select div.Division_key from Division div where div.Name 
= 'Metrostyle')
     END Division_fkey,
     DATEADD(Day, 7, cast(c.ActiveDate as smalldatetime)) as InHomeDate,
     cast(c.ActiveDate as smalldatetime) as ActivedDate,
     cast(c.InActiveDate as smalldatetime) as InactivedDate,
     NULL as Promo_fkey,
     NULL as Circulation,
     NULL as Priority,
     NULL as CurveStartDate,
     NULL as OldMedia_code,
     ((month(cast(c.ActiveDate as smalldatetime)) - 1)/3) + 1 as Quarter,
     NULL as InHomeDate2,
     NULL as LastYearsMedia_fkey,
     NULL as ParentMedia_fkey,
     NULL as ParentMediaRelationshipType_fkey,
     NULL as DefaultDemandCurve_fkey

from
[Zcollect] c
where not exists (Select m.Media_Code from Media m where c.media_code = 
m.media_code)
and c.season_code not in ('F09', 'S09', '999')
and c.Media_Code is NOT null
and substring (Cast(c.ActiveDate as Varchar), 1, 4) != '9999' and 
substring (Cast(c.InActiveDate as Varchar),1, 4) != '9999';

END
GO
