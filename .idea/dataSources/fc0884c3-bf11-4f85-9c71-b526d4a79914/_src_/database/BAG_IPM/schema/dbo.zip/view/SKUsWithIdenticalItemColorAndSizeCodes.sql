CREATE VIEW [dbo].[SKUsWithIdenticalItemColorAndSizeCodes]
AS
SELECT     i.Item_code, c.Color_code, sz.Size_code, seg.Name AS SegName,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Media_SKU AS ms
                            WHERE      (SKU_fkey = s.SKU_key)) AS MediaSKUCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.SKUPrice AS sp
                            WHERE      (SKU_fkey = s.SKU_key)) AS SKUPriceCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.SKUCost AS sc
                            WHERE      (SKU_fkey = s.SKU_key)) AS SKUCostCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Inventory AS inv
                            WHERE      (SKU_fkey = s.SKU_key)) AS InventoryCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.PurchaseOrder AS po
                            WHERE      (SKU_fkey = s.SKU_key)) AS POCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.BackOrders AS bo
                            WHERE      (SKU_fkey = s.SKU_key)) AS BOCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.GrossDemand AS gd
                            WHERE      (SKU_fkey = s.SKU_key)) AS GrossDemandCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Shipped AS sh
                            WHERE      (SKU_fkey = s.SKU_key)) AS ShippedCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.Cancellations AS ca
                            WHERE      (SKU_fkey = s.SKU_key)) AS CancCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.[Returns] AS re
                            WHERE      (SKU_fkey = s.SKU_key)) AS ReturnsCount,
                          (SELECT     COUNT(*) AS Expr1
                            FROM          dbo.SKUMediaForecastData AS smfd
                            WHERE      (SKU_fkey = s.SKU_key)) AS SKUMediaForecastDataCount, ri.Reference_code, div.Division_code, s.SKU_key, s.Item_fkey, s.Color_fkey, 
                      s.Size_fkey, ri.ReferenceItem_key, div.Division_key, seg.Segment_key, dep.Department_key,
                      itemsc.Name as ItemSizeClassName,
                      itemsc.SizeClass_key as ItemSizeClassKey,
                      sizesc.Name as SizeSizeClassName,
                      sizesc.SizeClass_key as SizeSizeClassKey,
					  (SELECT     min(s3.SKU_key)
                            FROM          dbo.SKU AS s3
                            INNER join Item i3 on i3.Item_key = s3.Item_fkey
                            inner join Size sz3 ON sz3.Size_key = s3.Size_fkey
                            inner join Color c3 on c3.Color_key = s3.Color_fkey
                            WHERE      (i3.Item_code = i.Item_code) AND (c3.Color_code = c.Color_code) AND (sz3.Size_code = sz.Size_code)) as MinSKUKey,
					  	(select MIN(a.ActivityDate) from 
							(select * from GrossDemand gd WHERE gd.SKU_fkey = s.SKU_key 
							UNION SELECT * from Returns ret where ret.SKU_fkey = s.SKU_key
							UNION SELECT * from Cancellations canc where canc.SKU_fkey = s.SKU_key
							UNION SELECT * from Shipped sh where sh.SKU_fkey = s.SKU_key) as a where a.SKU_fkey = s.SKU_key) as MinActivityDate


FROM         dbo.SKU AS s INNER JOIN
                      dbo.Item AS i ON i.Item_key = s.Item_fkey INNER JOIN
                      dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = i.ReferenceItem_fkey INNER JOIN
                      dbo.Department AS dep ON dep.Department_key = ri.Department_fkey INNER JOIN
                      dbo.Segment AS seg ON dep.Segment_fkey = seg.Segment_key INNER JOIN
                      dbo.Color AS c ON c.Color_key = s.Color_fkey INNER JOIN
                      dbo.Size AS sz ON sz.Size_key = s.Size_fkey INNER JOIN
                      dbo.SizeClass itemsc ON itemsc.SizeClass_key = i.SizeClass_fkey INNER JOIN
					  dbo.SizeClass sizesc ON sizesc.SizeClass_key = sz.SizeClass_fkey INNER JOIN
                      dbo.Division AS div ON div.Division_key = ri.Division_fkey
WHERE     EXISTS
                          (SELECT     SKU_key, Item_fkey, Color_fkey, Size_fkey, SKUDispositionStatusType_fkey, SKUBackOrderDispositionStatusType_fkey
                            FROM          dbo.SKU AS s2
                            INNER join Item i2 on i2.Item_key = s2.Item_fkey
                            inner join Size sz2 ON sz2.Size_key = s2.Size_fkey
                            inner join Color c2 on c2.Color_key = s2.Color_fkey
                            WHERE      (i2.Item_code = i.Item_code) AND (c2.Color_code = c.Color_code) AND (sz2.Size_code = sz.Size_code) AND (SKU_key <> s.SKU_key))
GO
