/*WHERE database_id = DB_ID( 'BAG_IPM Test1')
AND OBJECT_ID=OBJECT_ID('OverUnder')
order by TableName*/
CREATE VIEW [dbo].[TableUsageStats]
AS
SELECT     OBJECT_NAME(object_id) AS TableName, last_user_update, database_id, object_id, index_id, user_seeks, user_scans, user_lookups, user_updates, 
                      last_user_seek, last_user_scan, last_user_lookup, last_user_update AS Expr1, system_seeks, system_scans, system_lookups, system_updates, 
                      last_system_seek, last_system_scan, last_system_lookup, last_system_update
FROM         sys.dm_db_index_usage_stats
WHERE database_id = DB_ID( 'BAG_IPM')
GO
