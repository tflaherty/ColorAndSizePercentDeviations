CREATE VIEW [dbo].[VW_AllTTASKUSNeedingSizeRemapping]
AS
SELECT     s.sku_key, i.Item_code, c.Color_code, i.Item_key, c.Color_key, sz.Size_code, ssc.Name AS SizeSizeClass, isc.Name AS ItemSizeClass, 
                      ssc.SizeClass_key AS OldSizeClassKey, isc.SizeClass_key AS NewSizeClassKey, sz.Size_key AS OldSizeKey, sz2.Size_key AS NewSizeKey, i.ReferenceItem_fkey
FROM         dbo.SKU AS s INNER JOIN
                      dbo.Item AS i ON s.Item_fkey = i.Item_key INNER JOIN
                      dbo.SizeClass AS isc ON isc.SizeClass_key = i.SizeClass_fkey INNER JOIN
                      dbo.Color AS c ON c.Color_key = s.Color_fkey INNER JOIN
                      dbo.Size AS sz ON sz.Size_key = s.Size_fkey AND i.SizeClass_fkey <> sz.SizeClass_fkey INNER JOIN
                      dbo.SizeClass AS ssc ON ssc.SizeClass_key = sz.SizeClass_fkey LEFT OUTER JOIN
                      dbo.Size AS sz2 ON sz2.Size_code = sz.Size_code AND sz2.SizeClass_fkey = i.SizeClass_fkey
WHERE     (LEN(i.Item_code) = 6)

GO
