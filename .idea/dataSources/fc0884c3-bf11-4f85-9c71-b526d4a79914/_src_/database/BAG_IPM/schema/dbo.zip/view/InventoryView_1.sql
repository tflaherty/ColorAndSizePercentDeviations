CREATE VIEW dbo.InventoryView_1
AS
SELECT     TOP (100) PERCENT div, dept, Item_code, Description, Size_code, SUM(TotalUnitsUnrestricted) AS TotalUnitsUnrestricted, SUM(TotalUnitsBlocked) 
                      AS TotalUnitsBlocked, SUM(TotalUnitsQA) AS TotalUnitsQA
FROM         (SELECT     i.Item_code, ca.Description, sza.Size_code, d.Name AS dept, dv.Name AS div,
                                                  (SELECT     i.UnitCount
                                                    FROM          dbo.Inventory AS i INNER JOIN
                                                                           dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey AND 
                                                                           ist.Name = 'Unrestricted' AND s.SKU_key = i.SKU_fkey) AS TotalUnitsUnrestricted,
                                                  (SELECT     i.UnitCount
                                                    FROM          dbo.Inventory AS i INNER JOIN
                                                                           dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey AND ist.Name = 'Blocked' AND 
                                                                           s.SKU_key = i.SKU_fkey) AS TotalUnitsBlocked,
                                                  (SELECT     i.UnitCount
                                                    FROM          dbo.Inventory AS i INNER JOIN
                                                                           dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey AND ist.Name = 'QA' AND 
                                                                           s.SKU_key = i.SKU_fkey) AS TotalUnitsQA
                       FROM          dbo.SKU AS s INNER JOIN
                                              dbo.Item AS i ON i.Item_key = s.Item_fkey INNER JOIN
                                              dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = i.ReferenceItem_fkey INNER JOIN
                                              dbo.Department AS d ON d.Department_key = ri.Department_fkey INNER JOIN
                                              dbo.Division AS dv ON dv.Division_key = ri.Division_fkey INNER JOIN
                                              dbo.Color AS ca ON ca.Color_key = s.Color_fkey INNER JOIN
                                              dbo.Size AS sza ON sza.Size_key = s.Size_fkey) AS a
GROUP BY div, dept, Item_code, Description, Size_code WITH ROLLUP
HAVING      (SUM(TotalUnitsUnrestricted) > 0)
ORDER BY div, dept, Item_code, Description, Size_code
GO
