-- =============================================
-- Author:		Name
-- Create date: 
-- Description:	
-- =============================================
CREATE TRIGGER [dbo].[trg_User_LastModifiedDate_LastModifiedBy] 
   ON  [dbo].[User]
   AFTER UPDATE
AS 
	-- This makes the trigger return if another has 
	-- set Context_Info() to 0x55555
	DECLARE @Cinfo VARBINARY(128) 
	SELECT @Cinfo = Context_Info() 
	IF @Cinfo = 0x55555 
	RETURN  

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	UPDATE [User] SET [User].LastModifiedDate=getdate(), [User].LastModifiedBy=SUSER_SNAME()
	FROM [User] INNER JOIN Inserted ON [User].User_key = Inserted.User_key

END
GO
