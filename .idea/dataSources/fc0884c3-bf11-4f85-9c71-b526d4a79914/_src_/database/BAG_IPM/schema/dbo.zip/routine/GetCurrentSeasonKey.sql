-- =============================================
-- Author:		Thomas Flaherty
-- Create date: Nov. 1, 2010
-- Description:	Gets the current Season's key
-- =============================================
CREATE PROCEDURE [dbo].[GetCurrentSeasonKey]
	@CurrentSeasonKey int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT     TOP (1) @CurrentSeasonKey = Season_key
	FROM         Season
	WHERE     (StartDate <= CURRENT_TIMESTAMP)
	ORDER BY StartDate DESC
END
GO
