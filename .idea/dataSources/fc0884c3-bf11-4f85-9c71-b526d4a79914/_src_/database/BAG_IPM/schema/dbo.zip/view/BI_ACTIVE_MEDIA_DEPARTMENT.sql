CREATE VIEW [dbo].[BI_ACTIVE_MEDIA_DEPARTMENT]
AS
SELECT m.Media_code, d.Department_code, dape.GrossDemand AS PlanDptGDDollars, s.Season_code
FROM  dbo.Media AS m INNER JOIN
               dbo.DepartmentAssortmentPlan AS dap ON dap.Media_fkey = m.Media_key LEFT OUTER JOIN
               dbo.DepartmentAssortmentPlanEntry AS dape ON dape.DepartmentAssortmentPlan_fkey = dap.DepartmentAssortmentPlan_key LEFT OUTER JOIN
               dbo.Department AS d ON d.Department_key = dape.Department_fkey
               LEFT OUTER JOIN dbo.Season AS s ON s.Season_key = m.Season_fkey
WHERE (m.Media_key IN
                   (SELECT Media_key
                    FROM   dbo.ufGetKeysOfCurrentlyActiveMedia() AS ufGetKeysOfCurrentlyActiveMedia_1))
GO
