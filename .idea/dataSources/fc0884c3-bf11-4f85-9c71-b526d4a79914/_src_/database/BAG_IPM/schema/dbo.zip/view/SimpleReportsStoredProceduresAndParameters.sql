CREATE VIEW [dbo].[SimpleReportsStoredProceduresAndParameters]
AS
SELECT TOP (100) PERCENT SCHEMA_NAME(SO.schema_id) AS [Schema], SO.name AS ObjectName, SO.type_desc AS [ObjectType (UDF/SP)], 
               P.parameter_id AS ParameterID, P.name AS ParameterName, TYPE_NAME(P.user_type_id) AS ParameterDataType, P.max_length AS ParameterMaxBytes, 
               P.is_output AS IsOutPutParameter
FROM  sys.objects AS SO INNER JOIN
               sys.parameters AS P ON SO.object_id = P.object_id
WHERE (SO.object_id IN
                   (SELECT object_id
                    FROM   sys.objects
                    WHERE (type IN ('P', 'FN')))) AND (SO.name LIKE 'SR~_%' ESCAPE '~')
ORDER BY [Schema], ObjectName, ParameterID
GO
