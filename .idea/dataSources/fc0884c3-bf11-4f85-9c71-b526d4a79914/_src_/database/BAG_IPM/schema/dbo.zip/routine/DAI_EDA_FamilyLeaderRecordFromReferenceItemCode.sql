-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[DAI_EDA_FamilyLeaderRecordFromReferenceItemCode] 
(	
	-- Add the parameters for the function here
	@RefItemCode varchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT
		*
	from MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr
	where pr.FAMILY = @RefItemCode and pr.FAMILY_LEADER = 'Y'
)
GO
