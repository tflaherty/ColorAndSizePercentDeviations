CREATE VIEW dbo.ItemStatusCodeView
AS
SELECT  CASE WHEN len(i.Item_code) < 6 THEN RIGHT('00000' + CAST(i.Item_code AS varchar(128)), 5) + SPACE(1) + c.Color_code + SPACE(1) + sz.Size_code Collate Latin1_General_BIN
            ELSE CAST(i.Item_code AS varchar(128)) + SPACE(1) + c.Color_code + SPACE(1) + sz.Size_code Collate Latin1_General_BIN
         END as SKU,               
 
--right('0000' + cast(i.Item_code AS varchar), 5) + ' ' + (c.Color_code)+ ' ' + sz.size_code as SKU1,
       c.Color_code,
       sz.Size_code,
       sdt.Name as DispCode,
       si.Division_code 
--       sbo.name,
--       d.Department_code   
FROM
   SKU s
Cross Apply SKUINFO(s.SKU_key) as si
INNER JOIN Item i ON i.Item_key = s.Item_fkey
INNER JOIN Color c ON c.Color_key = s.Color_fkey
INNER JOIN [Size] sz ON sz.Size_key = s.Size_fkey 
--inner join ReferenceItem ri on ri.referenceItem_key = i.ReferenceItem_fkey
--inner join Department d on d.department_key = ri.Department_fkey
INNER JOIN SKUDispositionStatusType sdt ON sdt.SKUDispositionStatusType_key =
        s.SKUDispositionStatusType_fkey
--Left OUTER JOIN SKUBackOrderDispositionStatusType sbo ON sbo.SKUBackOrderDispositionStatusType_key =
--        s.SKUBackOrderDispositionStatusType_fkey
--where si.Division_code  = '3'
Group By i.Item_code,
         c.Color_code,
         sz.Size_code,
         sdt.Name,
         si.Division_code


GO
