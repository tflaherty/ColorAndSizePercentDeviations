-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[DAI_EDA_ProductsFromReferenceItemCode] 
(	
	-- Add the parameters for the function here
	@RefItemCode varchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT
		*
	from MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr
	where pr.PARENT_PRODUCT IN (SELECT pr2.id from MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr2 WHERE pr2.Inventory = 'PP' and pr2.FAMILY = @RefItemCode)
	and pr.Inventory = 'SY')
GO
