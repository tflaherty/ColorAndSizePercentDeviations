CREATE VIEW dbo.SizePlansThatDontAddUpToOneHundredPercent
AS
SELECT SUM(spe.PlannedPercentDemand) AS SumOfPercents, m.Media_code, ri.Reference_code, sc.Name AS SizeClass
FROM  dbo.SizePlanEntry AS spe INNER JOIN
               dbo.Size AS sz ON sz.Size_key = spe.Size_fkey INNER JOIN
               dbo.SizeClass AS sc ON sc.SizeClass_key = sz.SizeClass_fkey INNER JOIN
               dbo.ItemAssortmentPlan AS iap ON iap.SizePlan_fkey = spe.SizePlan_fkey INNER JOIN
               dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = iap.ReferenceItem_fkey INNER JOIN
               dbo.Media AS m ON m.Media_key = iap.Media_fkey
WHERE (spe.Deleted = 0)
GROUP BY spe.SizePlan_fkey, sz.SizeClass_fkey, m.Media_code, ri.Reference_code, sc.Name
HAVING (SUM(spe.PlannedPercentDemand) <> 1.0)
GO
