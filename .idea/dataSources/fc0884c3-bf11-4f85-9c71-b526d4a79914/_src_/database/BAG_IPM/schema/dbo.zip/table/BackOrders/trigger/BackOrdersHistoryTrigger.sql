-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[BackOrdersHistoryTrigger] 
   ON  [dbo].[BackOrders]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO dbo.BackOrdersHistory (ActivityDate, UnitCount, Media_fkey, SKU_fkey, [Date]) 
	SELECT ActivityDate, UnitCount, Media_fkey, SKU_fkey, GETDATE() from INSERTED;
END
GO
