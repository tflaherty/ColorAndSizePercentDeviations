CREATE VIEW [dbo].[SKUsWithMismatchedItemAndSizeSizeClasses]
AS
SELECT i.Item_code, c.Color_code, sz.Size_code, itemsc.Name AS ItemSizeClass, sizesc.Name AS SizeSizeClass, s.Size_fkey AS OldSizeKey,
                   (SELECT TOP (1) Size_key
                    FROM   dbo.Size AS newsz
                    WHERE (Size_code = sz.Size_code) AND (SizeClass_fkey = i.SizeClass_fkey)) AS NewSizeKey,
                   (SELECT TOP (1) IsShoeSize
                    FROM   dbo.Size AS newsz
                    WHERE (Size_code = sz.Size_code) AND (SizeClass_fkey = i.SizeClass_fkey)) AS IsNewSizeAShoeSize, 
					s.SKU_key, i.Item_key, ri.ReferenceItem_key,
					div.Division_key, div.Division_code, div.Name as Division,
                    seg.Segment_code
FROM  dbo.SKU AS s INNER JOIN
               dbo.Item AS i ON i.Item_key = s.Item_fkey INNER JOIN
               dbo.Color AS c ON c.Color_key = s.Color_fkey INNER JOIN
               dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = i.ReferenceItem_fkey INNER JOIN
			   dbo.Division div on div.Division_key = ri.Division_fkey INNER JOIN
               dbo.Department AS dep ON dep.Department_key = ri.Department_fkey LEFT OUTER JOIN
               dbo.Segment AS seg ON seg.Segment_key = dep.Segment_fkey INNER JOIN
               dbo.Size AS sz ON sz.Size_key = s.Size_fkey INNER JOIN
               dbo.SizeClass AS sizesc ON sizesc.SizeClass_key = sz.SizeClass_fkey INNER JOIN
               dbo.SizeClass AS itemsc ON itemsc.SizeClass_key = i.SizeClass_fkey AND sizesc.SizeClass_key <> itemsc.SizeClass_key
/*
 * You use this by dumping the results of this query for selected SKUs into a temporary table (let's call it TmpYYY) and then 
 * run an update script that looks like this:
 *     UPDATE SKU
 *      SET SKU.Size_fkey = (select top 1 TmpYYY.NewSizeKey FROM TmpYYY where TmpYYY.SKU_key = SKU.SKU_key)
 *      from SKU
 *      where SKU.SKU_key in (SELECT TmpYYY.SKU_key from TmpYYY)
 */
GO
