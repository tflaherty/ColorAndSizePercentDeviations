CREATE VIEW dbo.CFAndTSWebExAndWebClMediaCheck
AS
SELECT     m.Media_code, mt.Name AS mtName, mf.Name AS mfName, seas.Season_code, div.Name AS divName, seas.StartDate, m.Media_key, m.Division_fkey, 
                      CASE WHEN substring(m.Media_code, 3, 3) != seas.Season_code THEN 'N' WHEN substring(m.Media_code, 9, 2) = 'CL' AND 
                      mt.Name != 'Clearance' THEN 'N' WHEN substring(m.Media_code, 9, 2) = 'EX' AND 
                      mt.Name != 'Exclusive' THEN 'N' WHEN mf.Name != 'Web' THEN 'N' WHEN substring(m.Media_code, 1, 3) NOT IN ('TSF', 'TSS', 'CFF', 'CFS') 
                      THEN 'N' ELSE 'Y' END AS IsOkay
FROM         dbo.Media AS m INNER JOIN
                      dbo.MediaFormat AS mf ON mf.MediaFormat_key = m.MediaFormat_fkey INNER JOIN
                      dbo.MediaType AS mt ON mt.MediaType_key = m.MediaType_fkey INNER JOIN
                      dbo.Season AS seas ON seas.Season_key = m.Season_fkey INNER JOIN
                      dbo.Division AS div ON div.Division_key = m.Division_fkey
WHERE     (m.Division_fkey IN (4, 5)) AND (m.MediaFormat_fkey = 2) AND (m.MediaType_fkey IN (2, 4))
GO
