CREATE VIEW dbo.[Inventory By SKU]
AS
SELECT     TOP (100) PERCENT ita.Item_code, ca.Description, sza.Size_code,
                          (SELECT     SUM(i.UnitCount) AS Expr1
                            FROM          dbo.Inventory AS i INNER JOIN
                                                   dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey INNER JOIN
                                                   dbo.SKU AS s ON s.SKU_key = i.SKU_fkey INNER JOIN
                                                   dbo.Item AS it ON it.Item_key = s.Item_fkey INNER JOIN
                                                   dbo.Color AS c ON c.Color_key = s.Color_fkey INNER JOIN
                                                   dbo.Size AS sz ON sz.Size_key = s.Size_fkey
                            WHERE      (ist.Name = 'Unrestricted') AND (it.Item_code = ita.Item_code) AND (c.Description = ca.Description) AND (sz.Size_code = sza.Size_code)) 
                      AS TotalUnitsUnrestricted,
                          (SELECT     SUM(i.UnitCount) AS Expr1
                            FROM          dbo.Inventory AS i INNER JOIN
                                                   dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey INNER JOIN
                                                   dbo.SKU AS s ON s.SKU_key = i.SKU_fkey INNER JOIN
                                                   dbo.Item AS it ON it.Item_key = s.Item_fkey INNER JOIN
                                                   dbo.Color AS c ON c.Color_key = s.Color_fkey INNER JOIN
                                                   dbo.Size AS sz ON sz.Size_key = s.Size_fkey
                            WHERE      (ist.Name = 'Blocked') AND (it.Item_code = ita.Item_code) AND (c.Description = ca.Description) AND (sz.Size_code = sza.Size_code)) 
                      AS TotalUnitsBlocked,
                          (SELECT     SUM(i.UnitCount) AS Expr1
                            FROM          dbo.Inventory AS i INNER JOIN
                                                   dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey INNER JOIN
                                                   dbo.SKU AS s ON s.SKU_key = i.SKU_fkey INNER JOIN
                                                   dbo.Item AS it ON it.Item_key = s.Item_fkey INNER JOIN
                                                   dbo.Color AS c ON c.Color_key = s.Color_fkey INNER JOIN
                                                   dbo.Size AS sz ON sz.Size_key = s.Size_fkey
                            WHERE      (ist.Name = 'QA') AND (it.Item_code = ita.Item_code) AND (c.Description = ca.Description) AND (sz.Size_code = sza.Size_code)) 
                      AS TotalUnitsQA
FROM         dbo.Inventory AS i INNER JOIN
                      dbo.InventoryStatusType AS ist ON ist.InventoryStatusType_key = i.InventoryStatusType_fkey INNER JOIN
                      dbo.SKU AS s ON s.SKU_key = i.SKU_fkey INNER JOIN
                      dbo.Item AS ita ON ita.Item_key = s.Item_fkey INNER JOIN
                      dbo.Color AS ca ON ca.Color_key = s.Color_fkey INNER JOIN
                      dbo.Size AS sza ON sza.Size_key = s.Size_fkey
GROUP BY ita.Item_code, ca.Description, sza.Size_code
HAVING      (SUM(i.UnitCount) > 0)
ORDER BY ita.Item_code, ca.Description, sza.Size_code
GO
