-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[PrepareForEcometryFullImport]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

BEGIN TRY
    --Delete from PurchaseOrder;
    --Delete from BackOrders;
    --Delete from Inventory;
    ----Delete from SKUPrice;
    --Delete from Shipped
    --  where ActivityDate >= '07/01/2013';
    --Delete from Cancellations
    --  where ActivityDate >= '07/01/2013';
    --Delete from [Returns]
    --  where ActivityDate >= '07/01/2013';
    --Delete from GrossDemand
    --  where ActivityDate >= '07/01/2013';
    --Delete from GrossDemandMappingHistory
	--  where ActivityDate >= '07/01/2013';
    --Delete from SalesActivityMappingHistory
	--  where ActivityDate >= '07/01/2013';

	return 0
END TRY
BEGIN CATCH
	return 1
END CATCH
END
GO
