CREATE FUNCTION [dbo].[ufGetNextNextSeasonKey] 
(
)
RETURNS int
AS
BEGIN
	DECLARE @NextNextSeasonKey int

	SELECT    Top 1 @NextNextSeasonKey = s2.Season_key 
	FROM         Season AS s1 INNER JOIN
						  Season AS s2 ON s1.StartDate < s2.StartDate 
	WHERE     (s1.Season_key = dbo.ufGetNextSeasonKey()) 
	ORDER BY s2.StartDate ASC

	RETURN @NextNextSeasonKey
END
GO
