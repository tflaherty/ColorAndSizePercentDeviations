-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[WebRankingGroup1Priority1]  
(	
	@DivisionCode varchar(255),
	@SortBy varchar(255),
	@MediaCode varchar(255)
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT 
		a.Division_code,
		a.CategoryCode,
		a.CategoryName,
		a.GENDER,
		a.ClearanceFlags,
		a.ParentProductCode,
		a.Description,
		NULL as FirstAppearanceDateInSeason,
		a.PlanUnits,
		a.PlanDollars,
		a.ProjectedUnits,
		a.ProjectedDollars,
		a.InventoryUnits,
		a.OnOrderUnits,
		a.CurrentOverUnits,
		a.CurrentUnderUnits,
		1 as [Group],
		a.GrossDemandUnits,
		a.GrossDemandDollars,
		a.ReferenceItem_fkey as ReferenceItem_key,
		--(SELECT top 1 i2.Item_key from Item i2 WHERE i2.Item_code = a.ParentProductCode) as MasterItemKey,
		--(SELECT rimfd.IsProjecting from ReferenceItemMediaForecastData rimfd where rimfd.Media_fkey = a.Media_key and rimfd.ReferenceItem_fkey = a.ReferenceItem_fkey) as isProjecting,
		1 as Priority,
		CASE
			WHEN @SortBy = 'PlanUnits' THEN row_number() OVER (PARTITION BY a.CategoryCode ORDER BY a.CategoryCode, a.PlanUnits desc)
			WHEN @SortBy = 'PlanDollars' THEN row_number() OVER (PARTITION BY a.CategoryCode ORDER BY a.CategoryCode, a.PlanDollars desc)
			WHEN @SortBy = 'ProjectedDollars' THEN row_number() OVER (PARTITION BY a.CategoryCode ORDER BY a.CategoryCode, a.ProjectedDollars desc)
			WHEN @SortBy = 'ProjectedUnits' THEN row_number() OVER (PARTITION BY a.CategoryCode ORDER BY a.CategoryCode, a.ProjectedUnits desc)
		END as Ordinal
	from
	(SELECT
		div.Division_code,
		pc.CategoryCode,	
		pc.CategoryName,	
		--(SELECT TOP 1 GENDER from dbo.DAI_EDA_FamilyLeaderRecordFromReferenceItemCode(ri.Reference_code)) as GENDER,
		NULL as GENDER,
		NULL as ClearanceFlags,
		pc.ParentProductCode,		

		i.ReferenceItem_fkey, 
		ri.Description,
		dep.Department_code,
		dep.Department_key,
		div.Division_key,
		sum(isnull(smfd.PlanUnits, 0.0)) as PlanUnits,
		sum(isnull(smfd.PlanDollars, 0.0)) as PlanDollars,
		sum(isnull(smfd.ProjectedUnits, 0.0)) as ProjectedUnits,
		sum(isnull(smfd.ProjectedDollars, 0.0)) as ProjectedDollars,
		m.Media_key,
		sum(isnull(invsub.InventoryUnitCount, 0)) as InventoryUnits,
		NULL as GrossDemandUnits,
		NULL as GrossDemandDollars,
		sum(isnull(posub.OnOrderUnitCount, 0)) as OnOrderUnits,
		sum(isnull(oversub.CurrentOverUnitCount, 0)) as CurrentOverUnits,	
		sum(isnull(undersub.CurrentUnderUnitCount, 0)) as CurrentUnderUnits

	from Media m
	inner join Media_SKU ms on ms.Media_fkey = m.Media_key
	inner join SKU s ON s.SKU_key = ms.SKU_fkey
	inner join Item i on i.Item_key = s.Item_fkey
	inner join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
	inner join ProductCategory pc on pc.ParentProductCode = (SELECT top 1 pr2.ID from MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr2 where pr2.FAMILY_LEADER = 'Y' and pr2.INVENTORY = 'PP' AND pr2.FAMILY = ri.Reference_code order by pr2.ID)
	inner join Department dep ON dep.Department_key = ri.Department_fkey
	inner join Division div on div.Division_key = ri.Division_fkey
	left outer join SKUMediaForecastData smfd on smfd.SKU_fkey = s.SKU_key and smfd.Media_fkey = m.Media_key
	left outer join (SELECT SUM(inv.UnitCount) as InventoryUnitCount, inv.SKU_fkey from Inventory inv INNER join InventoryStatusType ist on ist.InventoryStatusType_key = inv.InventoryStatusType_fkey WHERE ist.Name = 'Unrestricted' GROUP BY inv.SKU_fkey) invsub on invsub.SKU_fkey = s.SKU_key
	left outer join (SELECT sum(pod.OpenQty) as OnOrderUnitCount, pod.SKU_fkey from PurchaseOrderDetail pod inner join PurchaseOrderMaster pom ON pom.PurchaseOrderMaster_key = pod.PurchaseOrderMaster_fkey where pod.DeliveryComplete = 0 GROUP BY pod.SKU_fkey) posub on posub.SKU_fkey = s.SKU_key
	left outer join (SELECT oum.CurrentOver as CurrentOverUnitCount, oum.SKU_fkey from OverUnderMaster oum) oversub on oversub.SKU_fkey = s.SKU_key
	left outer join (SELECT oum.CurrentUnder as CurrentUnderUnitCount, oum.SKU_fkey from OverUnderMaster oum) undersub on undersub.SKU_fkey = s.SKU_key
	where m.Media_code = @MediaCode
		AND cast(pc.Division_code as INT) = cast(@DivisionCode as INT)
		-- only select SKUs from Items and Reference Items with Current and undeleted plans in this Media (this is overkill but it takes care of weird cases)
		-- and exists (SELECT * from ItemAssortmentPlanSizeClassData iapscd inner join ItemAssortmentPlan iap on iap.ItemAssortmentPlan_key = iapscd.ItemAssortmentPlan_fkey inner join PlanType pt on pt.PlanType_key = iap.PlanType_fkey WHERE iapscd.Item_fkey = i.Item_key and iapscd.Deleted = 0 and iap.ReferenceItem_fkey = ri.ReferenceItem_key and iap.Media_fkey = m.Media_key and iap.Deleted = 0 and pt.Name = 'Current')
		and ms.Deleted = 0 
		-- put this back in if we only want to select core categories
		--and pc.CategoryCode in (select cscc2.CategoryCode from CoreSiteCategoryCode cscc2 INNER join Division div2 ON div2.Division_key = cscc2.Division_fkey WHERE cast(div2.Division_code as INT) = cast(@DivisionCode as int) )
	GROUP by i.ReferenceItem_fkey, ri.Description, pc.CategoryCode, pc.CategoryName, pc.ParentProductCode, dep.Department_code, dep.Department_key, div.Division_code, div.Division_key, m.Media_key) as a
)
GO
