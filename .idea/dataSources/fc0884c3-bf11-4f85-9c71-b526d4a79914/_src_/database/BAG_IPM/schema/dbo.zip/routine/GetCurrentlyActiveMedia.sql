-- =============================================
-- Author:		Thomas Flaherty
-- Create date: Nov. 1, 2010
-- Description:	Gets all the currently active Media
-- =============================================
CREATE PROCEDURE [dbo].[GetCurrentlyActiveMedia]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

SELECT Media.*
FROM     Media
WHERE  (ActivatedDate <= CURRENT_TIMESTAMP) AND (InactivatedDate > CURRENT_TIMESTAMP)

END
GO
