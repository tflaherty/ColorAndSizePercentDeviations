/*order by e.InHomeDate DESC, e.Media_code, e.Reference_code, e.Item_code, e.Color_code, e.Size_code, e.ActivityDate asc
order by e.absErrorPercent desc*/
CREATE VIEW [dbo].[CurvePredictionErrorAnalysis]
AS
SELECT
	g.Media_code,
	g.Reference_code,
	g.Item_code,
	g.Color_code,
	g.Size_code,
	g.DailySKUMediaUnitCount,
	g.PossibleActivityDate as ActivityDate,
	g.InHomeDate,
	g.DemandCurve_fkey,
	g.Media_fkey,
	g.ReferenceItem_key,
	g.Item_key,
	g.SKU_fkey,
	g.CurveOffsetFromInHome,
	g.StoredCurveStartDate,
	g.CurveName,
	g.TotalSKUMediaGDUnitCount,
	g.RunningSKUMediaGDUnitCount,
	g.DailySKUMediaGDPercentDone,
	g.RunningSKUMediaGDPercentDone,
	g.CurvePosition,
	g.CalculatedCurveStartDate,
	g.CalculatedCurvePercentDone,
	g.CalculatedCurvePercentDone - g.RunningSKUMediaGDPercentDone as errorPercent,
	(g.CalculatedCurvePercentDone - g.RunningSKUMediaGDPercentDone)/100.0 * g.TotalSKUMediaGDUnitCount as errorUnits,
	abs(g.CalculatedCurvePercentDone - g.RunningSKUMediaGDPercentDone) as absErrorPercent,
	abs(g.CalculatedCurvePercentDone - g.RunningSKUMediaGDPercentDone)/100.0 * g.TotalSKUMediaGDUnitCount as absErrorUnits,
	(g.CalculatedCurvePercentDone - g.RunningSKUMediaGDPercentDone) * (g.CalculatedCurvePercentDone - g.RunningSKUMediaGDPercentDone) as squaredErrorPercent
from
(SELECT
	f.*,
	CASE
		WHEN f.CurvePosition <= (select MAX(ce.Position) from CurveEntry ce where ce.Curve_fkey = f.DemandCurve_fkey) THEN (select 100.0*ce.Value from CurveEntry ce where ce.Curve_fkey = f.DemandCurve_fkey and ce.Position = f.CurvePosition)
		ELSE 100
	END as CalculatedCurvePercentDone,
	COALESCE((select sum(gd.UnitCount) from GrossDemand gd WHERE gd.SKU_fkey = f.SKU_fkey and gd.Media_fkey = f.Media_fkey and gd.ActivityDate = f.PossibleActivityDate), 0) as DailySKUMediaUnitCount,
	COALESCE((select sum(gd.UnitCount) from GrossDemand gd WHERE gd.SKU_fkey = f.SKU_fkey and gd.Media_fkey = f.Media_fkey and gd.ActivityDate <= f.PossibleActivityDate), 0) as RunningSKUMediaGDUnitCount,
	COALESCE((select sum(gd.UnitCount) from GrossDemand gd WHERE gd.SKU_fkey = f.SKU_fkey and gd.Media_fkey = f.Media_fkey and gd.ActivityDate = f.PossibleActivityDate), 0)*100.0/f.TotalSKUMediaGDUnitCount as DailySKUMediaGDPercentDone,
	COALESCE((select sum(gd.UnitCount) from GrossDemand gd WHERE gd.SKU_fkey = f.SKU_fkey and gd.Media_fkey = f.Media_fkey and gd.ActivityDate <= f.PossibleActivityDate), 0)*100.0/f.TotalSKUMediaGDUnitCount as RunningSKUMediaGDPercentDone
from
(select
	e.*,
	dl.Date as PossibleActivityDate,
	CASE
		WHEN e.StoredCurveStartDate is not NULL THEN datediff(day, e.StoredCurveStartDate, dl.Date)
		WHEN e.CurveOffsetFromInHome is not NULL then datediff(day, e.InHomeDate, dl.Date) - e.CurveOffsetFromInHome
	END  CurvePosition
from
(select
	d.*,
	DATEADD(day, (select MAX(ce.Position) from CurveEntry ce WHERE ce.Curve_fkey = d.DemandCurve_fkey), d.CalculatedCurveStartDate) as CalculatedCurveEndDate
from
(select
	c.*, 
	CASE
		WHEN c.StoredCurveStartDate is not NULL THEN c.StoredCurveStartDate
		WHEN c.CurveOffsetFromInHome is not NULL then dateadd(day, c.CurveOffsetFromInHome, c.InHomeDate)
	END  CalculatedCurveStartDate
FROM
(SELECT
	b.*,
	(SELECT Curve.OffsetFromInHomeDate from Curve where Curve.Curve_key = b.DemandCurve_fkey) as CurveOffsetFromInHome,
	(SELECT Curve.StartDate from Curve where Curve.Curve_key = b.DemandCurve_fkey) as StoredCurveStartDate,
	(SELECT Curve.Name from Curve where Curve.Curve_key = b.DemandCurve_fkey) as CurveName

from
(SELECT
	m.Media_code,
	ri.Reference_code,
	i.Item_code,
	c.Color_code,
	sz.Size_code,
	ri.ReferenceItem_key,
	i.Item_key,
	a.*,
	MIN(gd.ActivityDate) as MinActivityDate,
	MAX(gd.ActivityDate) as MaxActivityDate,
	SUM(gd.UnitCount) as TotalSKUMediaGDUnitCount,
	iapscd.DemandCurve_fkey,
	m.InHomeDate
from
(select
	distinct gdd.SKU_fkey, gdd.Media_fkey
	FROM GrossDemand gdd
) as a
INNER join GrossDemand gd on gd.SKU_fkey = a.SKU_fkey and gd.Media_fkey = a.Media_fkey
inner join SKU s on s.SKU_key = gd.SKU_fkey
inner join Color c on c.Color_key = s.Color_fkey
inner join Size sz on sz.Size_key = s.Size_fkey
inner join Item i on i.Item_key = s.Item_fkey -- AND i.Item_code = 66590
inner join ReferenceItem ri on ri.ReferenceItem_key = i.ReferenceItem_fkey
inner join Media m on m.Media_key = gd.Media_fkey
inner join ItemAssortmentPlan iap on iap.Media_fkey = m.Media_key AND iap.ReferenceItem_fkey = i.ReferenceItem_fkey and iap.Deleted = 0
INNER join PlanType pt on pt.PlanType_key = iap.PlanType_fkey AND pt.Name = 'Current'
inner join ItemAssortmentPlanSizeClassData iapscd on iapscd.ItemAssortmentPlan_fkey = iap.ItemAssortmentPlan_key and iapscd.Item_fkey = i.Item_key
GROUP by a.SKU_fkey, a.Media_fkey, iapscd.DemandCurve_fkey, m.InHomeDate, m.Media_code, ri.Reference_code, i.Item_code, c.Color_code, sz.Size_code, ri.ReferenceItem_key, i.Item_key) as b) as c) as d) as e
inner join DateLookup dl ON dl.Date >= e.CalculatedCurveStartDate and dl.Date <= (SELECT CASE WHEN e.CalculatedCurveEndDate > e.MaxActivityDate THEN e.CalculatedCurveEndDate ELSE e.MaxActivityDate END)) as f) as g
--ORDER by g.InHomeDate desc, g.SKU_fkey, g.Media_fkey, g.PossibleActivityDate


GO
