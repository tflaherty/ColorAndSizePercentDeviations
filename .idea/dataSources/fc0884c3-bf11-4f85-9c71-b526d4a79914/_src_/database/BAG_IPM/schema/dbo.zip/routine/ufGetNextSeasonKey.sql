-- =============================================
-- Author:		Thomas Flaherty
-- Create date: Nov. 2, 2010
-- Description:	Gets the key of the next Season
-- =============================================
CREATE FUNCTION [dbo].[ufGetNextSeasonKey]
(
)
RETURNS int
AS
BEGIN
	DECLARE @NextSeasonKey int

	SELECT    Top 1 @NextSeasonKey = s2.Season_key 
	FROM         Season AS s1 INNER JOIN
						  Season AS s2 ON s1.StartDate < s2.StartDate 
	WHERE     (s1.Season_key = dbo.ufGetCurrentSeasonKey()) 
	ORDER BY s2.StartDate ASC

	RETURN @NextSeasonKey
END
GO
