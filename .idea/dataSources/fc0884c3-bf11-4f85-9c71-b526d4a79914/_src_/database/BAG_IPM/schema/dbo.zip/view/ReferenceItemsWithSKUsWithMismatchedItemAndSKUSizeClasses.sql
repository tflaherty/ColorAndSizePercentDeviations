CREATE VIEW dbo.ReferenceItemsWithSKUsWithMismatchedItemAndSKUSizeClasses
AS
SELECT     Item_code, Item_key, ItemSizeClass, ReferenceItem_key, Division_key, COUNT(*) AS NumProblemSKUs, CASE WHEN EXISTS
                          (SELECT     TOP 1 seas.StartDate
                            FROM          ItemAssortmentPlan iap INNER JOIN
                                                   Media m ON m.Media_key = iap.Media_fkey INNER JOIN
                                                   Season seas ON seas.Season_key = m.Season_fkey
                            WHERE      iap.ReferenceItem_fkey = ReferenceItem_key
                            ORDER BY seas.StartDate DESC) THEN
                          (SELECT     TOP 1 seas.Season_code
                            FROM          ItemAssortmentPlan iap INNER JOIN
                                                   Media m ON m.Media_key = iap.Media_fkey INNER JOIN
                                                   Season seas ON seas.Season_key = m.Season_fkey
                            WHERE      iap.ReferenceItem_fkey = ReferenceItem_key
                            ORDER BY seas.StartDate DESC) ELSE NULL END AS LatestSeason
FROM         dbo.SKUsWithMismatchedItemAndSizeSizeClasses
GROUP BY ReferenceItem_key, Item_code, ItemSizeClass, Item_key, Division_key
GO
