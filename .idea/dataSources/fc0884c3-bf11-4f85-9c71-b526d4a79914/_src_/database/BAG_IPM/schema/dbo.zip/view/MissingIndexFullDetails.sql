CREATE VIEW dbo.MissingIndexFullDetails
AS
SELECT migs.last_user_seek, migs.last_user_scan, mid.statement, mid.equality_columns, mid.inequality_columns, migs.avg_total_user_cost, migs.avg_user_impact, 
               migs.avg_total_system_cost, migs.avg_system_impact, mid.included_columns, migs.unique_compiles, migs.user_seeks, migs.user_scans, migs.system_seeks, 
               migs.system_scans, migs.last_system_seek, migs.last_system_scan, mid.index_handle, mid.database_id, mid.object_id, mig.index_group_handle, 
               migs.group_handle
FROM  sys.dm_db_missing_index_details AS mid INNER JOIN
               sys.dm_db_missing_index_groups AS mig ON mig.index_handle = mid.index_handle INNER JOIN
               sys.dm_db_missing_index_group_stats AS migs ON migs.group_handle = mig.index_group_handle
GO
