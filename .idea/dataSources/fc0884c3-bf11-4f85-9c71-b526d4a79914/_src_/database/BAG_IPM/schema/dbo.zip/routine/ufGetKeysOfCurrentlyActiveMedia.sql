-- =============================================
-- Author:		Thomas Flaherty
-- Create date: Nov. 2, 2010
-- Description:	Gets a table of keys of the
--              currently active Media (plural)
-- =============================================
CREATE FUNCTION [dbo].[ufGetKeysOfCurrentlyActiveMedia]
(
)
Returns table
AS

	return SELECT Media.Media_key 
	FROM     Media
	WHERE  (ActivatedDate <= CURRENT_TIMESTAMP) AND (InactivatedDate > CURRENT_TIMESTAMP)
GO
