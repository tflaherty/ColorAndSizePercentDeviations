-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[WebRankingGroup2Priority4] 
(	
	@DivisionCode varchar(255),
	@SortBy varchar(255),
	@MediaDaysForward int,
	@MediaDaysBack int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT
		b.*,
		CASE
			--WHEN @SortBy in ('PlanUnits', 'ProjectedUnits') THEN row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.GrossDemandUnits desc)
			--ELSE row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.GrossDemandDollars desc)
			WHEN @SortBy = 'PlanUnits' THEN row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.PlanUnits desc, b.GrossDemandDollars desc)
			WHEN @SortBy = 'PlanDollars' THEN row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.PlanDollars desc, b.GrossDemandDollars desc)
			WHEN @SortBy = 'ProjectedDollars' THEN row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.ProjectedDollars desc, b.GrossDemandDollars desc)
			WHEN @SortBy = 'ProjectedUnits' THEN row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.ProjectedUnits desc, b.GrossDemandDollars desc)
			ELSE row_number() OVER (PARTITION BY b.CategoryCode ORDER BY b.CategoryCode, b.FirstAppearanceDateInSeason desc, b.GrossDemandDollars desc)
		END as Ordinal
	from
	(SELECT
		a.Division_code,
		a.CategoryCode,
		a.CategoryName,
		(SELECT TOP 1 GENDER from dbo.DAI_EDA_FamilyLeaderRecordFromReferenceItemCode(a.Reference_code)) as GENDER,			
		1 as ClearanceFlags,
		a.ParentProductCode,
		a.Description,
		a.FirstAppearanceDateInSeason,
		sum(isnull(smfd.PlanUnits, 0.0)) as PlanUnits,
		sum(isnull(smfd.PlanDollars, 0.0)) as PlanDollars,
		sum(isnull(smfd.ProjectedUnits, 0.0)) as ProjectedUnits,
		sum(isnull(smfd.ProjectedDollars, 0.0)) as ProjectedDollars,
		sum(isnull(invsub.InventoryUnitCount, 0)) as InventoryUnits,
		sum(isnull(posub.OnOrderUnitCount, 0)) as OnOrderUnits,
		sum(isnull(oversub.CurrentOverUnitCount, 0)) as CurrentOverUnits,	
		sum(isnull(undersub.CurrentUnderUnitCount, 0)) as CurrentUnderUnits,
		2 as [Group],
		sum(isnull(gdunitsub.GrossDemandUnitCount, 0)) as GrossDemandUnits,
		sum(isnull(gddollsub.GrossDemandActivePriceDollars, 0)) as GrossDemandDollars,
		a.ReferenceItem_key,
		4 as Priority
	from 
	(SELECT 
		ri.ReferenceItem_key,
		ri.Description,
		ri.Reference_code,
		pc.ParentProductCode,
		pc.CategoryCode,
		pc.CategoryName,
		pc.Division_code,
		(SELECT TOP 1 m2.Media_key from Media m2 
						inner join MediaFormat mf2 on mf2.MediaFormat_key = m2.MediaFormat_fkey
						inner join Media_SKU ms2 ON ms2.Media_fkey = m2.Media_key and ms2.Deleted = 0
						inner join SKU s2 on s2.SKU_key = ms2.SKU_fkey 
						inner join Item i2 on i2.Item_key = s2.Item_fkey 
						WHERE mf2.Name = 'Print' and m2.Season_fkey = dbo.ufGetCurrentSeasonKey() and i2.ReferenceItem_fkey = ri.ReferenceItem_key
						order BY m2.InHomeDate asc) AS FirstAppearanceMediaInSeason,
		(SELECT TOP 1 m2.InHomeDate from Media m2 
						inner join MediaFormat mf2 on mf2.MediaFormat_key = m2.MediaFormat_fkey
						inner join Media_SKU ms2 ON ms2.Media_fkey = m2.Media_key and ms2.Deleted = 0
						inner join SKU s2 on s2.SKU_key = ms2.SKU_fkey 
						inner join Item i2 on i2.Item_key = s2.Item_fkey 
						WHERE mf2.Name = 'Print' and m2.Season_fkey = dbo.ufGetCurrentSeasonKey() and i2.ReferenceItem_fkey = ri.ReferenceItem_key
						order BY m2.InHomeDate asc) AS FirstAppearanceDateInSeason
	from ReferenceItem ri
	inner join ProductCategory pc on pc.ParentProductCode = (SELECT top 1 pr2.ID from MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr2 where pr2.FAMILY_LEADER = 'Y' and pr2.INVENTORY = 'PP' AND pr2.FAMILY = ri.Reference_code order by pr2.ID)
	where cast(pc.Division_code as int) = CAST(@DivisionCode as int)) as a
	inner join Item i on i.ReferenceItem_fkey = a.ReferenceItem_key
	inner join SKU s ON s.Item_fkey = i.Item_key
	left outer join (SELECT SUM(inv.UnitCount) as InventoryUnitCount, inv.SKU_fkey from Inventory inv INNER join InventoryStatusType ist on ist.InventoryStatusType_key = inv.InventoryStatusType_fkey WHERE ist.Name = 'Unrestricted' GROUP BY inv.SKU_fkey) invsub on invsub.SKU_fkey = s.SKU_key
	left outer join (SELECT SUM(gd.UnitCount) as GrossDemandUnitCount, gd.SKU_fkey from GrossDemand gd WHERE gd.ActivityDate >= dateadd(day, -14, GETDATE()) GROUP BY gd.SKU_fkey) gdunitsub on gdunitsub.SKU_fkey = s.SKU_key
	left outer join (SELECT SUM(gd.ActivePrice) as GrossDemandActivePriceDollars, gd.SKU_fkey from GrossDemand gd WHERE gd.ActivityDate >= dateadd(day, -14, GETDATE()) GROUP BY gd.SKU_fkey) gddollsub on gddollsub.SKU_fkey = s.SKU_key
	left outer join (SELECT sum(pod.OpenQty) as OnOrderUnitCount, pod.SKU_fkey from PurchaseOrderDetail pod inner join PurchaseOrderMaster pom ON pom.PurchaseOrderMaster_key = pod.PurchaseOrderMaster_fkey where pod.DeliveryComplete = 0 GROUP BY pod.SKU_fkey) posub on posub.SKU_fkey = s.SKU_key
	left outer join (SELECT oum.CurrentOver as CurrentOverUnitCount, oum.SKU_fkey from OverUnderMaster oum) oversub on oversub.SKU_fkey = s.SKU_key
	left outer join (SELECT oum.CurrentUnder as CurrentUnderUnitCount, oum.SKU_fkey from OverUnderMaster oum) undersub on undersub.SKU_fkey = s.SKU_key
	left outer join SKUMediaForecastData smfd on smfd.SKU_fkey = s.SKU_key and smfd.Media_fkey = a.FirstAppearanceMediaInSeason
	where (a.FirstAppearanceDateInSeason is NULL or a.FirstAppearanceDateInSeason > dateadd(day, @MediaDaysForward, getdate()) or a.FirstAppearanceDateInSeason < dateadd(day, (@MediaDaysBack * -1), getdate()))
	-- make sure there are no SKUs for this reference item that's not in clearance (i.e. all the SKUs are in clearance
	and not EXISTS (SELECT * from MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr2 WHERE (pr2.INVENTORY = 'SY') AND (pr2.CLEARANCE = 0 OR pr2.CLEARANCE IS NULL) AND pr2.PARENT_PRODUCT in (select pr3.ID FROM MARSECOMEDATE.DAI_EDA.PRODUCT.PRODUCT pr3 WHERE pr3.INVENTORY = 'PP' and pr3.FAMILY = a.Reference_code) )
	-- this part tests to see if we have less than 50% of all possible colors, sizes and size classes for a reference item in unrestricted stock
	and (coalesce(CAST((SELECT COUNT(DISTINCT s2.SKU_key) from SKU s2 INNER join Item i2 on i2.Item_key = s2.Item_fkey WHERE i2.ReferenceItem_fkey = a.ReferenceItem_key AND EXISTS (SELECT * from Inventory inv2 inner join InventoryStatusType ist2 ON ist2.InventoryStatusType_key = inv2.InventoryStatusType_fkey WHERE inv2.SKU_fkey = s2.SKU_key and inv2.UnitCount > 0 and ist2.Name = 'Unrestricted')) as decimal) / 
			    nullif((SELECT COUNT(*)                   from SKU s3 INNER join Item i3 on i3.Item_key = s3.Item_fkey WHERE i3.ReferenceItem_fkey = a.ReferenceItem_key), 0), 0) 
		< .5)

	GROUP BY a.Division_code, a.ParentProductCode, a.CategoryCode, a.CategoryName, a.Reference_code, a.ReferenceItem_key, a.Description, a.FirstAppearanceDateInSeason) as b
)
GO
