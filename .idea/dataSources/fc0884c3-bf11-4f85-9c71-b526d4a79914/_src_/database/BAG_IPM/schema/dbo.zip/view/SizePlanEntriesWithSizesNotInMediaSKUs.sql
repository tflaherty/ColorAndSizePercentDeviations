CREATE VIEW dbo.SizePlanEntriesWithSizesNotInMediaSKUs
AS
SELECT     m.Media_code, ri.Reference_code,
                          (SELECT     TOP (1) i.Item_code
                            FROM          dbo.Item AS i INNER JOIN
                                                   dbo.SizeClass AS scItem ON scItem.SizeClass_key = i.SizeClass_fkey
                            WHERE      (i.ReferenceItem_fkey = ri.ReferenceItem_key) AND (scItem.Name IN ('MISSY', 'REGULAR', 'MEDIUM', 'SHOE', 'ONE SIZE', '32.0 Inseam', '9.0 Inseam'))) 
                      AS MasterItem, szSizeClass.Name AS SPESizeClass, szSizeClass.SizeClass_key AS SPESizeClassKey, m.Media_key, ri.ReferenceItem_key, 
                      iap.ItemAssortmentPlan_key, spe.SizePlan_fkey, spe.SizePlanEntry_key, ri.Division_fkey
FROM         dbo.SizePlanEntry AS spe INNER JOIN
                      dbo.Size AS sz ON sz.Size_key = spe.Size_fkey INNER JOIN
                      dbo.SizeClass AS szSizeClass ON szSizeClass.SizeClass_key = sz.SizeClass_fkey INNER JOIN
                      dbo.ItemAssortmentPlan AS iap ON iap.SizePlan_fkey = spe.SizePlan_fkey INNER JOIN
                      dbo.ReferenceItem AS ri ON ri.ReferenceItem_key = iap.ReferenceItem_fkey INNER JOIN
                      dbo.Media AS m ON m.Media_key = iap.Media_fkey
WHERE     (NOT EXISTS
                          (SELECT     ms2.Media_fkey, ms2.Deleted, ms2.SKU_fkey, s2.SKU_key, s2.Item_fkey, s2.Color_fkey, s2.Size_fkey, s2.SKUDispositionStatusType_fkey, 
                                                   s2.SKUBackOrderDispositionStatusType_fkey
                            FROM          dbo.Media_SKU AS ms2 INNER JOIN
                                                   dbo.SKU AS s2 ON s2.SKU_key = ms2.SKU_fkey
                            WHERE      (ms2.Media_fkey = iap.Media_fkey) AND (s2.Size_fkey = sz.Size_key))) AND (spe.Deleted = 0)
GO
