-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION MasterItemKeyFromReferenceItemKey 
(	
	-- Add the parameters for the function here
	@ReferenceItemKey int
)
RETURNS TABLE 
AS
RETURN 
(
select
	CASE
		WHEN exists (select itm.Item_key
            FROM Item itm
            INNER JOIN SizeClass sc ON sc.SizeClass_key = itm.SizeClass_fkey
            WHERE sc.Name IN  ('MISSY','REGULAR','MEDIUM','ONE SIZE','32.0 Inseam')
            AND itm.ReferenceItem_fkey = @ReferenceItemKey)
		THEN
			(select top 1 itm.Item_key
            FROM Item itm
            INNER JOIN SizeClass sc ON sc.SizeClass_key = itm.SizeClass_fkey
            WHERE sc.Name IN  ('MISSY','REGULAR','MEDIUM','ONE SIZE','32.0 Inseam')
            AND itm.ReferenceItem_fkey = @ReferenceItemKey)
		ELSE 
			(select top 1 itm.Item_key
            FROM Item itm
            INNER JOIN SizeClass sc ON sc.SizeClass_key = itm.SizeClass_fkey
            AND itm.ReferenceItem_fkey = @ReferenceItemKey order by itm.Item_key)

	END as MasterItemKey)
GO
