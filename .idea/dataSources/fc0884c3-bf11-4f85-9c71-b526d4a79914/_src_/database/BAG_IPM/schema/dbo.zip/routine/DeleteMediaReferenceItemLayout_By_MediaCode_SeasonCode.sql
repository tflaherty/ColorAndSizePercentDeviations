-- =============================================
-- Author:		Thomas Flaherty
-- Create date: 03/30/2012
-- Description:	Deletes all the MediaReferenceItemLayout
-- records for a given Media (with sometimes optional Season Code).
-- When we had 4 character long Media codes they didn't have the
-- Season as part of the code so we use the Season Code when deleting
-- records for those types of Media codes.  Otherwise we just use
-- the Media Code.
-- =============================================
CREATE PROCEDURE DeleteMediaReferenceItemLayout 
	@MediaCode varchar(128) = 0, 
	@SeasonCode varchar(128) = 0,
	@NumRowsDeleted int = 0 OUTPUT

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DELETE mril FROM MediaReferenceItemLayout mril
	INNER join Media m on m.Media_key = mril.Media_fkey
	inner join Season seas on seas.Season_key = m.Season_fkey
	where (len(m.Media_code) = 4 and seas.Season_code = @SeasonCode AND m.Media_code = @MediaCode) OR (len(m.Media_code) != 4 and m.Media_code = @MediaCode)

	select @NumRowsDeleted = @@ROWCOUNT
END
GO
